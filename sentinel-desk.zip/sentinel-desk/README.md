# Sentinel Desk

### SOC Log Analyzer & Alert Triage Dashboard

**Turn Windows event exports into an analyst-ready investigation.** Sentinel Desk is a Python and Flask portfolio project that demonstrates the daily work of a SOC analyst: identify suspicious activity, prioritize alerts, review evidence, document a decision, and recommend the next action.

The included synthetic dataset opens directly into a working dashboard. A reviewer can explore the project without an Active Directory domain, a paid SIEM, or production logs.

**Python 3.11+ · Flask · SQLite · Windows event analysis · MITRE ATT&CK · pytest**

**Demo at a glance: 63 events · 18 alerts · 11 High / 7 Medium · 5 fictional hosts**

## A two-minute recruiter walkthrough

1. Start the app and open **Overview** to see the event volume and prioritized alert queue.
2. Open **Successful login after repeated failures**. Review the linked failures, successful sign-in, affected identity, source address, and timeline.
3. Compare that activity with **Possible password spraying**: one source targets several accounts rather than repeatedly targeting one account.
4. Record an analyst note and update the investigation status. Refresh the page to see the saved decision.
5. Use **Event search** to investigate the account or source, then open **Detection rules** to inspect the logic and limitations behind the alert.

This is a hands-on work sample. Alerts represent evidence to investigate; they do not claim that an account is compromised.

## Skills demonstrated

| SOC skill | Evidence in this project |
| --- | --- |
| Authentication analysis | Time-window correlation of Windows 4625 failures and 4624 successes, grouped by account, host, domain, and source |
| Alert triage | Severity, concise findings, affected entities, supporting events, and recommended analyst actions |
| Investigation and documentation | Evidence timeline, event search, persistent investigation status, and analyst notes |
| Detection engineering | Separate, testable rules with documented thresholds, data requirements, and false-positive considerations |
| Windows security monitoring | Account creation, privileged group changes, lockouts, PowerShell indicators, and security-control changes |
| Threat-informed analysis | Relevant MITRE ATT&CK mappings with links to technique references |
| Python automation | CSV/JSON ingestion, timestamp normalization, deterministic event identifiers, and SQLite storage |
| Software delivery | Clear module boundaries, automated tests, GitHub Actions, and reproducible synthetic data |

## What the app includes

- A clean dashboard with summary metrics and a severity-prioritized alert queue.
- Alert investigations with supporting evidence, a chronological timeline, MITRE context, suggested next steps, status, and analyst notes.
- Searchable normalized events and a detection-rule reference view.
- CSV/JSON import through the app and Flask command line.
- Local SQLite persistence and deterministic synthetic Windows-style events.
- Core detection tests and a GitHub Actions test workflow.

## Start locally

Use **Python 3.11 or newer** and run these commands from the repository directory. No API keys, SIEM connection, or credentials are required.

### Windows PowerShell

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install -r requirements.txt
.\.venv\Scripts\python -m flask --app soc run --host 127.0.0.1
```

### macOS or Linux

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -m flask --app soc run --host 127.0.0.1
```

### Linux launcher

Extract the project into a folder owned by your regular user. With **Python 3.11+**, set it up once from the extracted `sentinel-desk` directory:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
sh run.sh
```

On subsequent runs, use `sh run.sh`. You can also run `chmod +x run.sh` once and then `./run.sh`. The launcher starts the dashboard on `127.0.0.1:5000` with the debugger and automatic reloader disabled. It uses a private file-creation mask for new database and session files; existing files retain their current permissions. Run it as your regular user, without `sudo`.

Create a new virtual environment on Linux; a copied Windows `.venv` will not work. If your distribution lacks `venv`, install its Python virtual-environment package using its package manager. Check `python3 --version`: on an older distribution you may need to use an explicitly installed interpreter such as `python3.11` in the setup command. Linux must also have Python's standard `sqlite3` module and write access to the project/instance directory. If you carried over a `SOC_DATABASE` environment setting, replace any Windows path with a Linux path.

The dashboard can analyze Windows CSV/JSON exports on Linux. Live Windows/Sysmon collection remains a separate integration; running the app on Linux does not enable live collection automatically.

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). The first startup creates `instance/soc.db` and loads the bundled demo into an empty database. Close the server with **Ctrl+C**. The examples use the environment's Python directly, so activating the environment or changing PowerShell execution policy is unnecessary.

After activating your virtual environment, the shorter commands below work on all platforms:

```text
python -m flask --app soc import-logs sample_data/demo_events.csv
python -m flask --app soc import-logs sample_data/demo_events.json
python -m flask --app soc load-demo
python -m pytest -q
```

CSV and JSON demo files contain the same records. Reimporting them should add no duplicate events. Imported logs and analyst notes stay in the local database across restarts.

For a clean lab database, set `SOC_AUTO_DEMO=0` **before the first start**. Set `SOC_DATABASE` to a separate database path if you want to keep the demo and lab work separate. For example, in PowerShell:

```powershell
$env:SOC_AUTO_DEMO = "0"
$env:SOC_DATABASE = "instance/lab.db"
.\.venv\Scripts\python -m flask --app soc import-logs local_logs/lab-export.csv
.\.venv\Scripts\python -m flask --app soc run --host 127.0.0.1
```

On macOS/Linux, prefix the equivalent command with `SOC_AUTO_DEMO=0 SOC_DATABASE=instance/lab.db`. Disabling the automatic demo does not delete existing events. To open that same lab database later, keep the same environment values. Investigation states are **New**, **Investigating**, **Closed — benign**, and **Closed — escalated**.

## Sample detections

The rule view in the running app provides the complete conditions and analyst guidance. The defaults below are intentionally transparent so an interviewer can discuss tuning and tradeoffs.

| Detection | Input and default condition | Severity | Relevant ATT&CK |
| --- | --- | --- | --- |
| Repeated failed logins | At least 5 × 4625 within 5 minutes for the same host, domain, account, and source | Medium | [T1110.001 Password Guessing](https://attack.mitre.org/techniques/T1110/001/) |
| Possible password spraying | At least 8 × 4625 across 5 distinct accounts from one source within 5 minutes | High | [T1110.003 Password Spraying](https://attack.mitre.org/techniques/T1110/003/) |
| Successful login after repeated failures | A 4624 strictly after at least 5 × 4625 in the preceding 10 minutes for the same host, domain, account, and source; the first success closes that failure sequence | High | [T1110.001 Password Guessing](https://attack.mitre.org/techniques/T1110/001/) |
| New user creation | 4720 account creation | Medium | [T1136 Create Account](https://attack.mitre.org/techniques/T1136/) |
| Privileged group membership change | Addition/removal events for recognized privileged group names or SIDs | High for additions; Medium for removals | [T1098.007 Additional Local or Domain Groups](https://attack.mitre.org/techniques/T1098/007/) for additions |
| Suspicious PowerShell | Indicators in 4104 script-block text or a 4688 PowerShell command line | High | [T1059.001 PowerShell](https://attack.mitre.org/techniques/T1059/001/) |
| Account lockout | 4740 lockout event | Medium | None; a lockout alone is insufficient for ATT&CK attribution |
| Security-control change | 1102 log clear; 4719 audit policy change; 4946–4948 firewall rule changes; 5025 firewall-service stop | High for log clear, explicit audit reduction, or firewall service stop; Medium for other changes | [T1685.005 Clear Windows Event Logs](https://attack.mitre.org/techniques/T1685/005/), [T1685.001 Disable or Modify Windows Event Log](https://attack.mitre.org/techniques/T1685/001/), or [T1686.003 Windows Host Firewall](https://attack.mitre.org/techniques/T1686/003/) for a firewall-service stop; generic changes have no ATT&CK attribution |

**ATT&CK mappings describe relevant behaviors, not verdicts.** A logon failure does not reveal which password was used; a spray-shaped pattern is an investigation lead. A success after failures remains part of the password-guessing investigation and does not establish valid-account abuse. User creation and group changes may be authorized. Generic policy changes, membership removals, and account lockouts receive no automatic ATT&CK attribution. This project uses the current T1685/T1686 families for logging/firewall impairment; older ATT&CK material may show retired T1070.001 or T1562 mappings.

Correlation windows include their boundary timestamps. The first matching successful login ends its preceding failure sequence, so later successes need a new qualifying set of failures. Importing older historical data can move the first qualifying trigger for a cluster and add a finding anchored to that earlier event; existing analyst findings remain stored. Review related findings together when adding historical exports.

### Example investigation

The demo includes six failed remote-interactive sign-ins to `morgan.lee` on `dc01.example.test` from `203.0.113.44`, followed by a successful sign-in from the same source. The alert links that evidence and recommends checking whether the user recognizes the activity, reviewing surrounding authentication/endpoint events, and escalating through an established incident-response process if compromise is supported.

Useful questions for an interview: What else would you check before escalating? How would shared gateways affect the source-IP correlation? How would a distributed or slow password spray evade the default window?

## Synthetic demo data

`sample_data/demo_events.csv` and `sample_data/demo_events.json` each contain **63 events** across **5 fictional hosts**, producing **18 alerts: 11 High and 7 Medium** under the default rules. They span a fictional workday on **October 6, 2026, 08:00–09:39 UTC**:

- 25 successful sign-ins and 19 failures, including a cross-account spray-shaped pattern, a single-account failure burst, and a later successful sign-in.
- Account creation, privileged membership additions/removal, and two lockouts.
- Routine inventory PowerShell plus suspicious, inert token markers for comparison.
- Security log clearing, audit coverage reduction/increase, a firewall-rule addition, and a firewall-service stop.
- A normal nonprivileged group addition that should not generate a privileged-group alert.

Every person, host, and incident is fictional. Hostnames use `example.test`; IPv4 addresses use documentation ranges. PowerShell samples are **log text with payloads omitted**, not runnable attack scripts. The app never executes event content or contacts the listed addresses.

## Architecture and data flow

```mermaid
flowchart LR
    A[CSV / JSON exports] --> B[Ingest and validate]
    B --> C[Normalize timestamps and fields]
    C --> D[(SQLite events)]
    D --> E[Detection rules and correlation]
    E --> F[(Alerts and evidence)]
    D --> G[Flask dashboard and search]
    F --> G
    G --> H[Analyst triage and notes]
    H --> F
```

Ingestion converts supported exports into a shared event model. Rules analyze normalized events and produce findings with evidence references. SQLite stores events, alerts, and investigation state. Flask routes assemble views; Jinja templates and local static assets present the analyst workflow.

```text
sentinel-desk/
├── soc/
│   ├── __init__.py          # Flask application factory and configuration
│   ├── ingestion.py         # CSV/JSON parsing and Windows field normalization
│   ├── detections.py        # Correlation, rules, severities, and ATT&CK mappings
│   ├── models.py            # Shared normalized event and alert models
│   ├── storage.py           # SQLite event, alert, and investigation persistence
│   ├── routes.py            # Dashboard, alerts, search, rules, and import routes
│   ├── templates/           # Analyst-facing pages
│   └── static/              # Local CSS and browser assets
├── sample_data/             # Matching fictional CSV and JSON exports
├── tests/                   # Detection and application tests
├── docs/                    # Input contract and screenshot guidance
├── .github/workflows/       # Automated test workflow
├── requirements.txt
├── run.sh                   # Linux local launcher after environment setup
└── LICENSE
```

See [the input contract](docs/input-format.md) for supported fields, formats, and log-source requirements.

## Screenshots

These screenshots come from the running app using the bundled fictional dataset. Any analyst notes or decisions shown are illustrative.

![Sentinel Desk overview with 63 fictional events and 18 alerts](docs/screenshots/dashboard.png)

| View | What it demonstrates |
| --- | --- |
| [Investigation](docs/screenshots/investigation.png) | Supporting evidence, timeline, ATT&CK, and an analyst decision |
| [Event search](docs/screenshots/event-search.png) | An account/source investigation using normalized Windows events |
| [Detection rules](docs/screenshots/detection-rules.png) | Explainable conditions, data needs, and tuning guidance |

See the [screenshot guide](docs/screenshots/README.md) when updating the portfolio images.

## Validation

```text
python -m pytest -q
```

Tests cover core correlation rules and the input cases that determine whether an alert is trustworthy. The GitHub Actions workflow is configured to run the suite on Python 3.11, 3.12, and 3.13 after the project is pushed to GitHub; it has not yet run on GitHub. A local passing run verifies this implementation; it is not a measurement of real-world detection precision or coverage.

**Local verification on October 7, 2026:** 161 tests passed with Python 3.12 and Flask 3.1.3. The app started successfully, its main pages returned HTTP 200 over localhost, and a submitted note/status update persisted. Desktop (1440 px) and mobile (390 px) layouts were checked using rendered browser captures. The matching CSV/JSON demo was also checked for identical normalized event fingerprints and the expected 63 events / 18 alerts. See [validation evidence and scope](docs/VALIDATION.md).

## Local security and operational scope

This release is a **single-user local portfolio/lab app**. Keep it bound to `127.0.0.1`. The Flask development server is for local evaluation; the project has no sign-in or role-based access controls for remote users. Add authentication, HTTPS, a production application server, access logging, and an appropriate deployment review before sharing a hosted instance.

No fixed signing key is checked in. On startup the app generates and persists a local session secret under the ignored `instance/` directory unless `SOC_SECRET_KEY` is supplied by the environment. The database and notes may contain sensitive material after importing lab exports, so `instance/` and `local_logs/` are excluded from Git. Place private exports in `local_logs/` and use synthetic data for public screenshots and repositories.

Imports are bounded to **5 MiB** per file, **20,000 rows** per import, and **25,000 unique stored events**. These limits keep the batch-analysis workload appropriate for a local demo; larger lab collections need a streaming adapter and a different storage/retention design.

The app is an explainable batch-analysis prototype. It does not parse native `.evtx` files, consume live Windows Event Forwarding, enrich threat intelligence, isolate endpoints, or automatically change accounts. Detection quality depends on enabled auditing, complete exports, correct time zones, stable account/host identities, and sufficient event fields. Slow/distributed attacks, missing sources, fragmented PowerShell script blocks, translated group names, and legitimate administrative changes require additional context and tuning.

## Roadmap: Active Directory lab to SIEM

| Stage | Planned work | Evidence to capture |
| --- | --- | --- |
| 1. Active Directory lab exports | Enable relevant auditing in the user's isolated lab; export selected fields with explicit UTC timestamps; compare with synthetic cases | Sanitized export examples, auditing checklist, and expected-vs-observed findings |
| 2. Windows Event Forwarding | Add a collector/export adapter, channel/provider metadata, record IDs, ingestion bookmarks, and duplicate handling | Collector architecture and loss/restart tests |
| 3. Better analyst context | Asset criticality, approved change windows, allowlists, rule tuning, and false-positive review | Tuning decisions with before/after results |
| 4. SIEM integration | Translate selected rules into Sigma/KQL/SPL, add a SIEM connector, and link an alert to source telemetry | Equivalent rule behavior and comparison results |
| 5. Operational hardening | Authentication, HTTPS, production serving, retention, bounded streaming correlation, and deployment-specific security checks | Access-control tests, performance baseline, and a documented runbook |

These are planned integrations; the initial release runs on exported CSV/JSON.

## References and license

Windows event semantics follow [Microsoft's Windows security event reference](https://learn.microsoft.com/en-us/azure/sentinel/windows-security-event-id-reference). PowerShell script-block coverage requires the appropriate logging and channel; see [Microsoft's PowerShell logging guidance](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_logging_windows). Framework setup follows the [Flask installation documentation](https://flask.palletsprojects.com/en/stable/installation/). ATT&CK links in the detection table provide the behavioral references.

Released under the [MIT License](LICENSE). Portfolio examples and demo events are original synthetic material.
