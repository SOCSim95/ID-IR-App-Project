"""Exercise imports, persistence, and the analyst workflow end to end."""
import io
import json
import re
from pathlib import Path

import pytest

from soc import create_app, storage
from soc.ingestion import read_events

SAMPLES = Path(__file__).resolve().parents[1] / "sample_data"


@pytest.fixture
def app(tmp_path):
    return create_app({"TESTING": True, "SECRET_KEY": "testing-only-key", "DATABASE": str(tmp_path / "test.db"), "AUTO_SEED": True})


@pytest.fixture
def client(app):
    return app.test_client()


def token(client, path="/import"):
    html = client.get(path).get_data(as_text=True)
    return re.search(r'name="csrf_token" value="([a-f0-9]+)"', html)[1]


def first_alert(app):
    return storage.list_alerts(app.config["DATABASE"])[0][0]["id"]


@pytest.mark.parametrize("path", ["/", "/alerts", "/events", "/rules", "/import", "/health", "/static/style.css", "/static/app.js"])
def test_all_pages_render(client, path):
    assert client.get(path).status_code == 200


def test_demo_metrics_and_detail(client, app):
    metrics = storage.dashboard(app.config["DATABASE"])
    assert (metrics["events"], metrics["open_alerts"], metrics["high_priority"], metrics["hosts"]) == (63, 18, 11, 5)
    alert_id = first_alert(app)
    html = client.get(f"/alerts/{alert_id}").get_data(as_text=True)
    assert "Evidence timeline" in html
    assert "Recommended next steps" in html
    assert "ATT&amp;CK context" in html
    assert "Original record" in html


def test_saved_triage_survives_restart_and_duplicate_import(client, app):
    alert_id = first_alert(app)
    path = f"/alerts/{alert_id}"
    response = client.post(path, data={"csrf_token": token(client, path), "status": "Investigating", "note": "Validated source with endpoint telemetry."})
    assert response.status_code == 302
    result = storage.import_events(app.config["DATABASE"], read_events((SAMPLES / "demo_events.csv").read_bytes(), "demo.csv"), "demo.csv")
    assert result == {"received": 63, "inserted": 0, "duplicates": 63, "alerts_added": 0}
    restarted = create_app({"TESTING": True, "SECRET_KEY": "testing-only-key", "DATABASE": app.config["DATABASE"], "AUTO_SEED": True})
    alert = storage.get_alert(restarted.config["DATABASE"], alert_id)
    assert alert["status"] == "Investigating"
    assert [n["body"] for n in alert["notes"]] == ["Validated source with endpoint telemetry."]
    assert len(alert["activity"]) == 1


@pytest.mark.parametrize("path", ["/import", "/alerts/unknown"])
def test_csrf_required(client, path):
    assert client.post(path, data={"status": "Investigating"}).status_code == 400
    assert client.post(path, data={"csrf_token": "wrong"}).status_code == 400


def test_import_complete_batch_or_nothing(client, app):
    records = [{"timestamp": "2026-10-07T10:00:00Z", "event_id": 4720, "account": "new.user"}, {"event_id": 4625}]
    response = client.post("/import", data={"csrf_token": token(client), "file": (io.BytesIO(json.dumps(records).encode()), "events.json")}, follow_redirects=True)
    assert response.status_code == 200
    assert "error" in response.get_data(as_text=True)
    assert storage.dashboard(app.config["DATABASE"])["events"] == 63


def test_import_and_cross_batch_detection(client, app):
    def upload(records):
        return client.post("/import", data={"csrf_token": token(client), "file": (io.BytesIO(json.dumps(records).encode()), "events.json")}, follow_redirects=True)
    failures = [{"timestamp": f"2026-10-07T10:00:0{i}Z", "event_id": 4625, "host": "dc.test", "account": "cross.batch", "source_ip": "192.0.2.22"} for i in range(5)]
    assert upload(failures).status_code == 200
    success = {**failures[0], "timestamp": "2026-10-07T10:01:00Z", "event_id": 4624}
    assert upload([success]).status_code == 200
    alerts, _ = storage.list_alerts(app.config["DATABASE"], query="cross.batch")
    assert {a["rule_id"] for a in alerts} == {"failed_login_burst", "success_after_failures"}


def test_sql_queries_are_bound_and_like_is_literal(client, app):
    for query in ("' OR 1=1 --", "%", "_"):
        rows, total = storage.list_alerts(app.config["DATABASE"], query=query)
        assert rows == [] and total == 0
    assert client.get("/events?event_id=4625").status_code == 200
    assert storage.search_events(app.config["DATABASE"], event_id=4625)[1] == 19


def test_untrusted_notes_and_raw_logs_escape(client, app):
    alert_id = first_alert(app)
    path = f"/alerts/{alert_id}"
    client.post(path, data={"csrf_token": token(client, path), "status": "New", "note": '<script>alert("x")</script>'})
    html = client.get(path).get_data(as_text=True)
    assert '<script>alert("x")</script>' not in html
    assert "&lt;script&gt;" in html
    event = {"timestamp": "2026-10-07T11:00:00Z", "event_id": 4720, "account": "<script>untrusted</script>"}
    storage.import_events(app.config["DATABASE"], read_events(json.dumps([event]), "x.json"), "test")
    html = client.get("/events?q=untrusted").get_data(as_text=True)
    assert "<script>untrusted</script>" not in html
    assert "&lt;script&gt;untrusted&lt;/script&gt;" in html


def test_invalid_status_and_oversized_note_preserve_triage(client, app):
    alert_id = first_alert(app)
    path = f"/alerts/{alert_id}"
    for status, note in (("Invalid", "text"), ("Investigating", "x" * 4001)):
        client.post(path, data={"csrf_token": token(client, path), "status": status, "note": note})
    alert = storage.get_alert(app.config["DATABASE"], alert_id)
    assert alert["status"] == "New" and alert["notes"] == []


@pytest.mark.parametrize("path", ["/missing", "/alerts/missing"])
def test_unknown_page(client, path):
    assert client.get(path).status_code == 404


@pytest.mark.parametrize("path", ["/alerts?severity=unknown", "/events?event_id=abc", "/events?start=broken", "/events?start=2026-10-07T10:00&end=2026-10-06T10:00"])
def test_invalid_filters(client, path):
    assert client.get(path).status_code == 400


def test_headers_hosts_and_upload_limit(client, app):
    response = client.get("/")
    assert response.headers["X-Content-Type-Options"] == "nosniff"
    assert "frame-ancestors 'none'" in response.headers["Content-Security-Policy"]
    assert "HttpOnly" in response.headers["Set-Cookie"]
    assert "SameSite=Strict" in response.headers["Set-Cookie"]
    assert client.get("/", headers={"Host": "external.example.test"}).status_code == 400
    app.config["MAX_CONTENT_LENGTH"] = 1024
    assert client.post("/import", data={"csrf_token": token(client), "file": (io.BytesIO(b"x" * 2048), "huge.json")}).status_code == 413


def test_event_capacity_failure_rolls_back(app, monkeypatch):
    monkeypatch.setattr(storage, "MAX_EVENTS", 63)
    event = {"timestamp": "2026-10-07T11:00:00Z", "event_id": 4720, "account": "overflow"}
    with pytest.raises(ValueError, match="storage limit"):
        storage.import_events(app.config["DATABASE"], read_events(json.dumps([event]), "test.json"), "test")
    assert storage.dashboard(app.config["DATABASE"])["events"] == 63


def test_cli_import_and_demo_deduplicate(app):
    runner = app.test_cli_runner()
    imported = runner.invoke(args=["import-logs", str(SAMPLES / "demo_events.csv")])
    assert imported.exit_code == 0
    assert "0 new events; 63 duplicates; 0 new alerts" in imported.output
    demo = runner.invoke(args=["load-demo"])
    assert demo.exit_code == 0
    assert "0 new events" in demo.output


def test_empty_workspace_and_pagination(tmp_path):
    app = create_app({"TESTING": True, "SECRET_KEY": "testing-only-key", "DATABASE": str(tmp_path / "empty.db"), "AUTO_SEED": False})
    client = app.test_client()
    assert client.get("/").status_code == 200
    assert "No alerts to show" in client.get("/alerts").get_data(as_text=True)
    assert "No matching events" in client.get("/events").get_data(as_text=True)
    records = [{"timestamp": "2026-10-07T11:00:00Z", "event_id": 4720, "account": f"account-{i}"} for i in range(35)]
    storage.import_events(app.config["DATABASE"], read_events(json.dumps(records), "test.json"), "test")
    html = client.get("/alerts?page=1&q=account").get_data(as_text=True)
    assert "page=2" in html and "q=account" in html
    assert client.get("/alerts?page=2").status_code == 200
    assert client.get("/events?page=2").status_code == 200
