"""Input contracts: Windows aliases, UTC normalization, deduplication, and rejection."""

import csv
import io
import json
from datetime import datetime, timezone

import pytest

from soc.ingestion import IngestionError, normalize_event, normalize_records, read_events
from soc.models import Event


def record(**overrides):
    item = {
        "timestamp": "2026-09-21T09:00:00Z",
        "event_id": 4625,
        "computer": "DC01",
        "account": "alice",
        "domain": "CORP",
        "source_ip": "192.0.2.10",
        "event_record_id": "1234",
    }
    item.update(overrides)
    return item


def test_canonical_fields_normalize_to_utc_event():
    normalized = normalize_event(record())
    assert normalized.timestamp == datetime(2026, 9, 21, 9, 0, tzinfo=timezone.utc)
    assert normalized.event_id == 4625
    assert normalized.host == "dc01"
    assert normalized.account == "alice"
    assert normalized.domain == "corp"
    assert normalized.source_ip == "192.0.2.10"
    assert normalized.details["event_record_id"] == "1234"
    assert normalized.id


def test_windows_export_aliases_normalize_to_equivalent_identity():
    windows_record = {
        "TimeCreated": "2026-09-21T09:00:00Z",
        "EventID": "4625",
        "Computer": "DC01",
        "TargetUserName": "alice",
        "TargetDomainName": "CORP",
        "IpAddress": "192.0.2.10",
        "EventRecordID": 1234,
        "SubjectUserName": "auth-service",
        "LogonType": "3",
    }
    normalized = normalize_event(windows_record)
    assert normalized.event_id == 4625
    assert normalized.account == "alice"
    assert normalized.domain == "corp"
    assert normalized.source_ip == "192.0.2.10"
    assert normalized.details["subject_account"] == "auth-service"
    assert normalized.details["logon_type"] == "3"


def test_nested_event_data_preserves_fields_needed_for_detection():
    normalized = normalize_event({
        "TimeCreated": "2026-09-21T09:00:00Z",
        "EventID": 4732,
        "Computer": "DC01",
        "EventData": {
            "TargetUserName": "Administrators",
            "TargetSid": "S-1-5-32-544",
            "MemberName": "CORP\\alice",
            "MemberSid": "S-1-5-21-1-2-3-1101",
            "SubjectUserName": "admin.operator",
        },
    })
    assert normalized.details["group_name"] == "administrators"
    assert normalized.details["group_sid"] == "S-1-5-32-544"
    assert normalized.details["member_name"] == "corp\\alice"
    assert normalized.details["subject_account"] == "admin.operator"


def test_xml_to_json_system_and_named_data_arrays_are_supported():
    normalized = normalize_event({"Event": {
        "System": {"EventID": {"#text": "4625"},
                   "TimeCreated": {"@SystemTime": "2026-09-21T09:00:00Z"},
                   "Computer": "DC01"},
        "EventData": {"Data": [
            {"@Name": "TargetUserName", "#text": "alice"},
            {"@Name": "TargetDomainName", "#text": "CORP"},
            {"@Name": "IpAddress", "#text": "192.0.2.10"},
        ]},
    }})
    assert normalized.event_id == 4625
    assert normalized.account == "alice"
    assert normalized.domain == "corp"
    assert normalized.source_ip == "192.0.2.10"


def test_domain_qualified_account_is_split_into_account_and_domain():
    normalized = normalize_event(record(account="OTHER\\alice", domain=""))
    assert normalized.account == "alice"
    assert normalized.domain == "other"


def test_actor_domain_does_not_override_qualified_target_account_domain():
    normalized = normalize_event({
        "TimeCreated": "2026-09-21T09:00:00Z", "EventID": 4720,
        "TargetUserName": "OTHER\\alice", "SubjectUserName": "administrator",
        "SubjectDomainName": "CORP",
    })
    assert normalized.account == "alice"
    assert normalized.domain == "other"
    assert normalized.details["subject_domain"] == "corp"


def test_actor_domain_is_not_assumed_for_an_unqualified_target_account():
    normalized = normalize_event({
        "TimeCreated": "2026-09-21T09:00:00Z", "EventID": 4720,
        "TargetUserName": "alice", "SubjectUserName": "administrator",
        "SubjectDomainName": "CORP",
    })
    assert normalized.account == "alice"
    assert normalized.domain == ""


def test_subject_only_events_keep_the_actor_domain():
    normalized = normalize_event({
        "TimeCreated": "2026-09-21T09:00:00Z", "EventID": 1102,
        "SubjectUserName": "administrator", "SubjectDomainName": "CORP",
    })
    assert normalized.account == "administrator"
    assert normalized.domain == "corp"


@pytest.mark.parametrize("member,domain", [("CORP\\alice", "corp"), ("alice@corp.test", "corp.test")])
def test_qualified_group_member_is_normalized_without_duplicated_display_domain(member, domain):
    normalized = normalize_event({
        "TimeCreated": "2026-09-21T09:00:00Z", "EventID": 4732,
        "TargetUserName": "Administrators", "TargetSid": "S-1-5-32-544",
        "MemberName": member, "SubjectUserName": "operator", "SubjectDomainName": "OTHER",
    })
    assert normalized.account == "alice"
    assert normalized.domain == domain
    assert normalized.details["member_name"] == member.casefold()
    assert normalized.display_account == f"{domain}\\alice"


def test_ipv4_mapped_ipv6_source_is_normalized_for_correlation():
    assert normalize_event(record(source_ip="::ffff:192.0.2.10")).source_ip == "192.0.2.10"


@pytest.mark.parametrize("event_id,field,value,expected", [
    (4104, "ScriptBlockText", "Get-Service", "script_block_text"),
    (4688, "CommandLine", "powershell.exe Get-Date", "command_line"),
    (4688, "NewProcessName", "powershell.exe", "process_name"),
    (4719, "AuditPolicyChanges", "Success removed", "change"),
])
def test_windows_detection_fields_are_extracted(event_id, field, value, expected):
    normalized = normalize_event({"TimeCreated": "2026-09-21T09:00:00Z",
                                  "EventID": event_id, field: value})
    assert normalized.details[expected] == value


def test_offset_timestamp_is_converted_to_utc():
    normalized = normalize_event(record(timestamp="2026-09-21T05:00:00-04:00"))
    assert normalized.timestamp == datetime(2026, 9, 21, 9, 0, tzinfo=timezone.utc)


def test_naive_timestamp_requires_explicit_timezone_assumption():
    with pytest.raises(IngestionError):
        normalize_event(record(timestamp="2026-09-21T05:00:00"))
    normalized = normalize_event(record(timestamp="2026-09-21T05:00:00"),
                                 assume_timezone="-04:00")
    assert normalized.timestamp == datetime(2026, 9, 21, 9, 0, tzinfo=timezone.utc)


@pytest.mark.parametrize("assumption", ["UTC", "Z", "+00:00"])
def test_explicit_utc_assumptions_are_supported(assumption):
    normalized = normalize_event(record(timestamp="2026-09-21T09:00:00"),
                                 assume_timezone=assumption)
    assert normalized.timestamp == datetime(2026, 9, 21, 9, 0, tzinfo=timezone.utc)


@pytest.mark.parametrize("assumption", ["America/New_York", "+24:00", "+00:60"])
def test_ambiguous_or_invalid_timezone_assumption_is_rejected(assumption):
    with pytest.raises(IngestionError):
        normalize_event(record(timestamp="2026-09-21T05:00:00"), assume_timezone=assumption)


def test_empty_source_marker_does_not_create_an_ip_identity():
    assert normalize_event(record(source_ip="-")).source_ip == ""


def test_equivalent_csv_and_json_imports_produce_same_event_ids():
    payload = record()
    csv_buffer = io.StringIO()
    writer = csv.DictWriter(csv_buffer, fieldnames=list(payload))
    writer.writeheader()
    writer.writerow(payload)
    json_event = read_events(json.dumps([payload]), "security.json")[0]
    csv_event = read_events(csv_buffer.getvalue(), "security.csv")[0]
    assert json_event.id == csv_event.id
    assert json_event.timestamp == csv_event.timestamp
    assert json_event.details == csv_event.details


@pytest.mark.parametrize("payload", [lambda item: [item], lambda item: {"events": [item]},
                                    lambda item: item])
def test_json_supported_record_containers(payload):
    events = read_events(json.dumps(payload(record())), "input.json")
    assert len(events) == 1
    assert events[0].event_id == 4625


@pytest.mark.parametrize("extension", ["CSV", "JSON"])
def test_utf8_bom_and_case_insensitive_extensions(extension):
    if extension == "CSV":
        payload = "timestamp,event_id,computer\n2026-09-21T09:00:00Z,4624,DC01\n"
    else:
        payload = json.dumps([record(event_id=4624)])
    events = read_events(b"\xef\xbb\xbf" + payload.encode("utf-8"), f"input.{extension}")
    assert len(events) == 1
    assert events[0].event_id == 4624


def test_duplicate_records_are_removed_and_output_is_chronological():
    first = record(timestamp="2026-09-21T09:00:00Z", event_record_id="1")
    later = record(timestamp="2026-09-21T09:05:00Z", event_record_id="2")
    events = normalize_records([later, first, first])
    assert len(events) == 2
    assert events[0].timestamp < events[1].timestamp


def test_distinct_windows_record_ids_preserve_simultaneous_events():
    events = normalize_records([record(event_record_id=100), record(event_record_id=101)])
    assert len(events) == 2
    assert events[0].id != events[1].id


def test_export_only_metadata_does_not_change_deduplication_identity():
    events = normalize_records([record(), record(export_filename="other-file.json",
                                                RowNumber=999)])
    assert len(events) == 1


def test_aliases_and_record_id_types_share_deduplication_identity():
    windows = {"TimeCreated": "2026-09-21T09:00:00Z", "EventID": "4625", "Computer": "DC01",
               "TargetUserName": "alice", "TargetDomainName": "CORP", "IpAddress": "192.0.2.10",
               "EventRecordID": 1234}
    assert normalize_event(windows).id == normalize_event(record()).id


def test_unknown_event_ids_remain_available_for_search():
    events = normalize_records([record(event_id=9999)])
    assert events[0].event_id == 9999


def test_event_serialization_round_trip_preserves_identity_and_fields():
    normalized = normalize_event(record(command_line="powershell.exe Get-Date"))
    restored = Event.from_dict(normalized.to_dict())
    assert restored.id == normalized.id
    assert restored.timestamp == normalized.timestamp
    assert restored.details == normalized.details
    assert restored.event_id == normalized.event_id


@pytest.mark.parametrize("overrides", [
    {"timestamp": "not-a-date"},
    {"timestamp": "2026-02-30T09:00:00Z"},
    {"timestamp": ""},
    {"event_id": "not-an-event"},
    {"event_id": "4625.5"},
    {"event_id": 65536},
    {"event_id": -1},
    {"event_id": True},
    {"event_id": None},
])
def test_malformed_events_raise_actionable_input_errors(overrides):
    with pytest.raises(IngestionError) as error:
        normalize_event(record(**overrides))
    assert str(error.value)


@pytest.mark.parametrize("payload", ["{", "[]", "{}", "null", '"a string"', "[1]",
                                    '{"events": "not an array"}'])
def test_invalid_or_empty_json_is_rejected(payload):
    with pytest.raises(IngestionError):
        read_events(payload, "input.json")


def test_mixed_valid_and_invalid_json_does_not_silently_drop_invalid_rows():
    payload = json.dumps([record(), record(timestamp="bad-date", event_record_id=1235)])
    with pytest.raises(IngestionError):
        read_events(payload, "input.json")


@pytest.mark.parametrize("payload", ["", "timestamp,event_id\n", "event_id\n4625\n"])
def test_empty_or_incomplete_csv_is_rejected(payload):
    with pytest.raises(IngestionError):
        read_events(payload, "input.csv")


@pytest.mark.parametrize("payload", [
    "timestamp,event_id,EventID\n2026-09-21T09:00:00Z,4625,4625\n",
    "timestamp,event_id\n2026-09-21T09:00:00Z,4625,unexpected-extra-field\n",
    "timestamp,event_id\n2026-09-21T09:00:00Z\n",
])
def test_ambiguous_headers_and_csv_row_shape_errors_are_rejected(payload):
    with pytest.raises(IngestionError):
        read_events(payload, "input.csv")


@pytest.mark.parametrize("filename", ["events.exe", "events.xml", "events.evtx", "events"])
def test_unsupported_file_types_are_rejected(filename):
    with pytest.raises(IngestionError):
        read_events(json.dumps([record()]), filename)


def test_invalid_utf8_is_reported_as_ingestion_error():
    with pytest.raises(IngestionError):
        read_events(b"\xff\xfe\xff", "events.json")


@pytest.mark.parametrize("embedded", [False, True])
def test_unpaired_unicode_surrogates_are_reported_as_ingestion_errors(embedded):
    payload = json.dumps([record(details={"message": "\ud800"})]) if embedded else "\ud800"
    with pytest.raises(IngestionError, match="Unicode"):
        read_events(payload, "events.json")


@pytest.mark.parametrize("number", [float("nan"), float("inf"), float("-inf")])
def test_nonfinite_json_numbers_are_rejected(number):
    with pytest.raises(IngestionError, match="non-finite"):
        read_events(json.dumps([record(details={"numeric_value": number})]), "events.json")


@pytest.mark.parametrize("embedded", [False, True])
def test_excessive_nested_data_is_rejected_even_inside_encoded_event_data(embedded):
    value = {"message": "synthetic"}
    for _ in range(40):
        value = {"nested": value}
    payload = record(EventData=json.dumps(value)) if embedded else record(details=value)
    with pytest.raises(IngestionError, match="nested too deeply"):
        read_events(json.dumps([payload]), "events.json")


@pytest.mark.parametrize("timestamp", ["0001-01-01T00:00:00+01:00", "9999-12-31T23:00:00-02:00"])
def test_timezone_conversion_range_overflow_is_an_ingestion_error(timestamp):
    with pytest.raises(IngestionError, match="supported date range"):
        normalize_event(record(timestamp=timestamp))


def test_oversized_upload_is_rejected_before_parsing():
    with pytest.raises(IngestionError, match="limit"):
        read_events(b"x" * (10 * 1024 * 1024 + 1), "events.json")


def test_record_count_limit_is_enforced():
    with pytest.raises(IngestionError):
        normalize_records([record()] * 20_001)
