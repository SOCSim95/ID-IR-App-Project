#!/bin/sh
# Start the local demo using the virtual environment created during setup.
set -eu
umask 077

soc_script_dir=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$soc_script_dir"
soc_python_bin="$soc_script_dir/.venv/bin/python"

if [ ! -x "$soc_python_bin" ]; then
    printf '%s\n' 'First create a Linux virtual environment in this project:' >&2
    printf '%s\n' '  python3 -m venv .venv' >&2
    printf '%s\n' '  .venv/bin/python -m pip install -r requirements.txt' >&2
    printf '%s\n' 'Then run: sh run.sh' >&2
    exit 1
fi

if ! "$soc_python_bin" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)'; then
    printf '%s\n' 'Python 3.11 or newer is required. Recreate .venv with a supported interpreter.' >&2
    exit 1
fi

if ! "$soc_python_bin" -c 'import flask, sqlite3' >/dev/null 2>&1; then
    printf '%s\n' 'Flask and SQLite support are required. Install requirements.txt in .venv.' >&2
    exit 1
fi

printf '%s\n' 'Sentinel Desk: open http://127.0.0.1:5000 on this machine.'
printf '%s\n' 'Press Ctrl+C to stop.'
exec "$soc_python_bin" -m flask --app soc --no-debug run --host 127.0.0.1 --port 5000 --no-debugger --no-reload
