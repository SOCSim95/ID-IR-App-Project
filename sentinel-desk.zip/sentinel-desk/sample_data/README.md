# Synthetic Windows-style event exports

`demo_events.csv` and `demo_events.json` contain the **same 63 records**, sorted by event time. They are authored fictional examples, not exports from a live environment. The app loads the JSON version automatically into a fresh empty demo database; the CSV version exercises the second ingestion path.

The default rules produce **18 alerts: 11 High and 7 Medium**, across **5 hosts**. Expected rule totals are 1 failure burst, 1 possible spray, 1 success after failures, 1 new user, 4 privileged group changes, 3 suspicious PowerShell findings, 2 lockouts, and 5 security-control changes.

| Event ID | Records | Scenario |
| --- | ---: | --- |
| 4624 | 25 | 24 routine successes and one success after repeated failures |
| 4625 | 19 | 3 isolated mistakes, 10 cross-account failures, and 6 single-account failures |
| 4688 | 4 | 3 routine inventory processes and 1 suspicious inert command marker |
| 4104 | 2 | Suspicious inert PowerShell script-block markers |
| 4720 | 1 | Account creation |
| 4728 | 2 | One privileged global-group addition and one normal nonprivileged addition |
| 4732 / 4756 | 1 each | Privileged local/universal-group additions |
| 4733 | 1 | Privileged local-group removal |
| 4740 | 2 | Account lockouts with caller-computer context |
| 1102 | 1 | Security log cleared |
| 4719 | 2 | Audit coverage reduction and increase |
| 4946 | 1 | Firewall rule added |
| 5025 | 1 | Windows Firewall service stopped |

Events span **2026-10-06 08:00:12–09:39:10 UTC**. Each includes a fictional record ID and provider/channel context. Event 4104 explicitly belongs to the PowerShell Operational channel; the remaining records use the Security channel. All hosts use `example.test` and all addresses use documentation ranges.

The suspicious PowerShell records contain indicator names and omitted-content markers only. There is no encoded payload, download URL, or executable attack script. Treat every command/script field as evidence text.

The records include legitimate-looking administrative activity because real SOC triage requires checking authorization and context. A medium-priority audit-policy change or a privileged membership removal is not automatically an attack. The demo does not include change-management evidence, owner verification, endpoint telemetry, or threat-intelligence attribution.

Do not replace these files with private lab exports in a public repository. Keep private exports under the ignored `local_logs/` directory.
