# Input contract

Sentinel Desk analyzes **exported, structured event records**. Start with the bundled `sample_data/demo_events.csv` or `sample_data/demo_events.json` and use the same canonical fields for lab exports. Native `.evtx` files and unstructured Event Viewer message text require an export adapter before import.

JSON may be an array, one event object, or an object containing an `events`/`Events` array. The parser also accepts selected Windows-style `Event` → `System`/`EventData` structures. `EventData` can be an object or a named `Data` array with `Name`/`@Name` and `#text`/`text`/`Value` entries. XML text itself is not supported.

## Canonical JSON example

```json
[
  {
    "timestamp": "2026-10-06T09:20:00Z",
    "event_id": 4625,
    "computer": "dc01.example.test",
    "account": "morgan.lee",
    "domain": "example.test",
    "source_ip": "203.0.113.44",
    "logon_type": "10",
    "event_record_id": 81040,
    "details": {
      "message": "Synthetic unsuccessful remote-interactive sign-in",
      "synthetic": true
    }
  }
]
```

## Canonical CSV example

CSV must have a header. Quote embedded commas and quotes using normal CSV escaping. Use UTF-8 text.

```csv
timestamp,event_id,computer,account,domain,source_ip,logon_type
2026-10-06T09:20:00Z,4625,dc01.example.test,morgan.lee,example.test,203.0.113.44,10
```

`details` may be a JSON object in JSON input or a JSON-encoded string in a CSV cell. The matching demo files show a complete example. Optional empty fields are valid; do not invent a source address or affected account when the original event does not provide one.

## Fields

| Canonical field | Purpose |
| --- | --- |
| `timestamp` | Event occurrence time as ISO 8601, with `Z` or an explicit UTC offset |
| `event_id` | Integer Windows event identifier |
| `computer` | Host that generated the event; keep its identity consistent across exports |
| `account` | Affected account for authentication, account creation, and lockout events; use explicit actor/member fields for administrative changes |
| `domain` | Account domain or local-account authority; prevents similarly named accounts in different domains being combined |
| `source_ip` | Authentication source IP when present; can be empty for non-network events |
| `logon_type` | Windows logon type, retained as supporting context |
| `subject_account` | Actor that performed an administrative operation |
| `target_account` | Affected account when exported separately from the actor |
| `group_name` / `group_sid` | Group affected by a membership change; SID is useful for localized group names |
| `member_name` / `member_sid` | Member added to or removed from a group |
| `command_line` | Recorded process command line, especially for Security event 4688 |
| `script_block_text` | Recorded PowerShell script-block content for event 4104 |
| `change` | Audit/firewall change detail, such as `Success removed; Failure removed` |
| `category` / `subcategory` | Optional audit-policy context |
| `event_record_id` | Original source record identifier; retained in normalized details and contributes to event identity |
| `details` | Additional structured context; recognized fields are normalized and the original object remains in the raw record |

`timestamp` and `event_id` identify when and what occurred. Useful correlation also requires the host, account/domain, and source address relevant to the rule. Sparse events can remain searchable without triggering rules that lack the necessary evidence.

Always export timestamps with a timezone. For example, `2026-10-06T05:20:00-04:00` represents the same instant as `2026-10-06T09:20:00Z`. Imports reject naive timestamps unless a fixed timezone is explicitly supplied. If an export's timezone is known, the CLI accepts an explicit fixed assumption through `--assume-timezone UTC` or `--assume-timezone=-04:00`; regional daylight-saving time is not inferred. Correct the export's timestamps where possible.

## Supported Windows-style aliases

Field matching ignores capitalization, spaces, underscores, and punctuation. Examples include:

| Canonical value | Common accepted aliases |
| --- | --- |
| Event identifier | `EventID`, `Id`, `EventCode` |
| Timestamp | `TimeCreated` (including `SystemTime`/`@SystemTime`), `TimeGenerated`, `@timestamp`, `DateTime` |
| Host | `host`, `ComputerName`, `Hostname`, `MachineName` |
| Account | `TargetUserName`, `UserName`, `User`, `SubjectUserName` |
| Domain | `TargetDomainName`, `AccountDomain`; `SubjectDomainName` is a fallback for a matching subject identity |
| Source address | `IpAddress`, `SourceNetworkAddress`, `SourceIP`, `ClientAddress`, `ClientIP` |
| Actor/member | `SubjectUserName`, `MemberName`, `MemberSid` |
| Process command/name | `CommandLine`, `ProcessCommandLine`, `NewProcessName`, `Image` |
| Script-block content | `ScriptBlockText`, `ScriptText`, `Script` |
| Audit change | `AuditPolicyChanges`, `Changes`, `PolicyChange`, `ChangeType` |
| Source record ID | `EventRecordID`, `RecordId`, `RecordNumber` |

Use canonical fields when building a new adapter. Accounts in `DOMAIN\user` or `user@domain` form are split into account/domain when no explicit domain exists. Host and identity values are normalized for case-insensitive comparison; script/command text retains its original content. Recognized IP addresses use a canonical form, including IPv4-mapped IPv6 addresses. For group events, Windows `TargetUserName`/`TargetSid` supply group context and `MemberName`/`MemberSid` identify the affected member. Preserve these roles instead of treating the group as a user.

Keep actor and target domains separate. An actor's `SubjectDomainName` is not automatically assigned to an unrelated target account. Domain-qualified group members supply their own identity/domain rather than inheriting the group or modifying actor's domain.

## Data required by each detection

| Detection | Events | Required supporting data |
| --- | --- | --- |
| Failure burst | 4625 | Host, domain/account, source address, timestamps |
| Possible password spray | 4625 | One source address, distinct domain/account identities, timestamps |
| Success after failures | 4625 followed strictly later by 4624 | Same host, domain/account, and source; timestamps; first success ends the preceding failure sequence |
| New account | 4720 | Target account and actor context when available |
| Privileged membership change | 4728/4732/4756 additions; 4729/4733/4757 removals | Recognized privileged group name or SID; member and actor context when available |
| Suspicious PowerShell | 4104; 4688 with a PowerShell process/command | Suspicious script-block or command-line tokens; a process name alone is insufficient |
| Lockout | 4740 | Target account and caller context when available; this event may not contain a source IP |
| Security-control changes | 1102, 4719, supported firewall change/stop events | Actor and explicit change data when available; generic changes receive a lower priority than demonstrated reduction |

## Important Windows logging distinctions

- **4624/4625** are successful/failed logon events. They do not by themselves provide a password, prove a spray, or establish compromise.
- **4688** is a process-creation event in the Security log. Its command-line field can be empty unless command-line auditing is enabled. Missing command-line data limits the PowerShell rule. [Microsoft 4688 reference](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4688)
- **4104** comes from a PowerShell Operational channel, not the Windows Security channel. Include script-block content from `Microsoft-Windows-PowerShell/Operational` (Windows PowerShell) or `PowerShellCore/Operational` (PowerShell 7) when your lab logging supports it. The app does not reconstruct fragmented script blocks. [Microsoft PowerShell logging reference](https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_logging_windows)
- **4719** means an audit-policy change occurred. Supply the actual additions/removals to distinguish reduced coverage from a benign increase. The app does not query the host's current policy. [Microsoft 4719 reference](https://learn.microsoft.com/en-us/windows/security/threat-protection/auditing/event-4719)
- Group membership event IDs indicate the operation; use group name/SID to decide whether the affected group is privileged. Missing or translated group labels reduce coverage unless the exported SID is recognized.

## Import and provenance

Use the app's import page or the command line from an activated virtual environment:

```text
python -m flask --app soc import-logs local_logs/lab-export.csv
python -m flask --app soc import-logs local_logs/lab-export.json
```

Normalization retains the original record alongside the shared event fields. The SHA-256 event fingerprint covers UTC occurrence time, event ID, normalized host/account/domain/source, and recognized detail fields including a source record ID when provided. Unknown raw metadata does not change the fingerprint. Without a source record ID, two otherwise identical records at the same timestamp collapse into one; export record IDs to preserve genuinely distinct events. Source record IDs alone are not globally unique across hosts/channels.

Imports parse and validate the complete file before saving it. An invalid event identifier, missing/invalid timestamp, malformed JSON/CSV, unsupported encoding/type, or exceeded limit rejects the whole import with an actionable error. Unknown but valid Windows event IDs remain searchable even when no rule covers them. Duplicate event IDs refer to event types; deterministic record fingerprints handle duplicate records.

Keep private lab exports under the ignored `local_logs/` directory. Before adding new public samples, replace personal data and internal infrastructure with fictional values; exclude credentials, tokens, and live command payloads.

The app limits each import to 5 MiB, the parser limits a file to 20,000 rows, and the local database limits storage to 25,000 unique events. (The standalone parser also enforces a 10 MiB content ceiling; the app applies the stricter 5 MiB limit.) Use smaller, targeted lab exports instead of a complete high-volume collector dump. To import into a clean lab database, set `SOC_AUTO_DEMO=0` before initialization and choose a separate path with `SOC_DATABASE`; see the repository README for an example.

Adding historical records can change the earliest qualifying trigger of a correlation cluster. The app preserves existing analyst findings and can add a finding tied to that earlier event rather than merging every historical cluster into a single investigation. Review overlapping findings together when backfilling older exports. For successful-login correlation, the first matching success closes the preceding failures; later successes require a new failure sequence.

## Integration boundary

The canonical schema is the stable starting point for an Active Directory or Windows Event Forwarding adapter. Export structured properties rather than relying on localized rendered messages. A later connector should preserve provider/channel metadata, source record IDs, UTC timestamps, loss/restart bookmarks, and enough subject/target context to avoid confusing actors with affected identities.
