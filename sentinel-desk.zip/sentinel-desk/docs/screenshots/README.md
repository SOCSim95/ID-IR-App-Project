# Portfolio screenshots

The included images were captured from the rendered app on October 7, 2026 using the bundled synthetic dataset. They are ready to use in the portfolio README. Visible analyst notes and decisions are illustrative.

| Image | View |
| --- | --- |
| [dashboard.png](dashboard.png) | Overview with metrics, severity overview, and prioritized alerts |
| [investigation.png](investigation.png) | Successful-login-after-failures investigation, showing evidence and timeline |
| [event-search.png](event-search.png) | Search using normalized Windows event fields |
| [detection-rules.png](detection-rules.png) | Rule reference with thresholds and ATT&CK context |

## Updating the images

Use only the bundled synthetic dataset for public images. Capture at a desktop viewport near 1440 pixels wide. Keep navigation visible, hide unrelated browser tabs, and ensure event text remains readable. If a screenshot is taller than the viewport, use a complete page capture so recommended actions and saved notes are included. Also check the app at a narrow viewport near 390 pixels wide before replacing images.

Preserve the filenames above so existing README links continue to work. Embed images using relative Markdown paths, for example:

```markdown
![Sentinel Desk dashboard with fictional demo data](docs/screenshots/dashboard.png)
```

Avoid publishing live accounts, internal hostnames, private analyst notes, or other sensitive data in screenshots.
