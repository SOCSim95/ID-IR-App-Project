# Validation record

**Verified locally on October 7, 2026.** This record describes the completed local checks and their scope. It does not claim production readiness, real-world detection effectiveness, or a completed GitHub Actions run.

## Environment and automated tests

| Item | Result |
| --- | --- |
| Python | 3.12 |
| Flask | 3.1.3 |
| Test command | `python -m pytest -q` |
| Local result | **161 tests passed** |
| GitHub Actions | Configured for Python 3.11, 3.12, and 3.13; **not yet run on GitHub** |

The automated suite covers:

- Correlation thresholds and inclusive time boundaries; separation of accounts, domains, hosts, and sources; success sequencing; deterministic alert identifiers; and benign/missing-data cases.
- Supported Windows aliases and nested export shapes; UTC normalization and explicit timezone assumptions; duplicate handling; malformed/oversized input; and retaining unsupported event types without invented detections.
- Page rendering, SQLite persistence across restart/reimport, cross-batch detection, atomic import rollback, CSRF protection, escaped notes/raw logs, literal search behavior, invalid statuses/filters, trusted hosts, and storage limits.

## Synthetic data checks

The CSV and JSON exports were parsed through the project's actual normalization module. Both produced the same **63 normalized event fingerprints** in chronological order, with UTC timestamps and **5 distinct fictional hosts**.

The default rules produced **18 alerts: 11 High and 7 Medium**:

| Rule | Findings |
| --- | ---: |
| Repeated failed logins | 1 |
| Possible password spraying | 1 |
| Successful login after repeated failures | 1 |
| New user account created | 1 |
| Privileged group membership changed | 4 |
| Suspicious PowerShell indicators | 3 |
| Account locked out | 2 |
| Security control changed | 5 |

Reimporting equivalent demo records did not create duplicate normalized events. These totals describe this authored dataset, not coverage of arbitrary Windows exports.

## Running application checks

The Flask app started successfully with debug mode disabled and a loopback listener. Requests to the Overview, alert queue, investigation, event search, detection rules, import, and health views returned **HTTP 200** over localhost. A live form submission saved an analyst note and investigation status; the resulting state was verified afterward.

Browser rendering was checked at **1440 pixels wide** for desktop and **390 pixels wide** for mobile. The main analyst views were captured with synthetic data, and observed overflow was corrected before the final captures. The [included screenshots](screenshots/README.md) show the rendered application.

## Limits and remaining verification

- The app limits imports to **5 MiB**, the parser limits each file to **20,000 records**, and SQLite storage is bounded to **25,000 unique events**.
- This release supports exported CSV/JSON. Native EVTX, live Active Directory collection, Windows Event Forwarding, and SIEM connectors remain roadmap work.
- The application is a local single-user tool with no sign-in or role-based permissions. Public hosting requires additional deployment work.
- Script/command contents are treated as data. Synthetic PowerShell samples contain inert indicator markers with payloads omitted.
- Adding historical records can generate an additional finding at an earlier correlation trigger while preserving existing analyst findings. Review overlapping backfill findings together.
- Local browser checks demonstrate the tested layouts. They are not an exhaustive accessibility audit or a cross-browser certification.
- CI is configured, but GitHub publication and its hosted test matrix were not performed as part of this local delivery.

To repeat the automated checks after installing the documented dependencies, run `python -m pytest -q`. Start the app using the repository README and verify the views against the bundled synthetic dataset.

## Linux support update — October 9, 2026

A portability review found no Windows-specific runtime imports or executable calls in the application. `run.sh` now starts the app from a Linux virtual environment, keeps its listener on loopback, disables the debugger/reloader, and sets a private creation mask for new runtime files. The source archive includes the launcher and Linux setup instructions.

The Ubuntu CI matrix now includes shell syntax validation and an HTTP startup check of the launcher. These Linux checks are **configured but have not yet run on a Linux host or on GitHub**. Development in this chat used Windows; an actual Linux execution remains a validation step for the target machine or hosted CI.
