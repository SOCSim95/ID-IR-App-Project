"""Deterministic, explainable detection rules over normalized Windows events.

ATT&CK links describe behavior worth investigating, not confirmed compromise.
Time windows are inclusive; successes must strictly follow their evidence.
"""

from __future__ import annotations

from collections import Counter, defaultdict, deque
from datetime import timedelta
import hashlib
import re
from typing import Any, Iterable, Mapping

from .models import Alert, Event


def _mitre(identifier: str, name: str) -> dict[str, str]:
    return {"id": identifier, "name": name,
            "url": "https://attack.mitre.org/techniques/" + identifier.replace(".", "/") + "/"}


PASSWORD_GUESSING = _mitre("T1110.001", "Brute Force: Password Guessing")
PASSWORD_SPRAYING = _mitre("T1110.003", "Brute Force: Password Spraying")
CREATE_ACCOUNT = _mitre("T1136", "Create Account")
GROUP_ADDITION = _mitre("T1098.007", "Account Manipulation: Additional Local or Domain Groups")
POWERSHELL = _mitre("T1059.001", "Command and Scripting Interpreter: PowerShell")
AUDIT_REDUCTION = _mitre("T1685.001", "Disable or Modify Tools: Disable or Modify Windows Event Log")
CLEAR_LOGS = _mitre("T1685.005", "Disable or Modify Tools: Clear Windows Event Logs")
FIREWALL = _mitre("T1686.003", "Disable or Modify System Firewall: Windows Host Firewall")


def _rule(identifier: str, title: str, severity: str, event_ids: list[int],
          rationale: str, actions: tuple[str, ...], false_positives: tuple[str, ...],
          inputs: str, mitre: tuple[dict[str, str], ...] = (), threshold: str = "One qualifying event",
          window_minutes: int | None = None) -> dict[str, Any]:
    return {"id": identifier, "name": title, "title": title, "severity": severity,
            "event_ids": event_ids, "rationale": rationale, "description": rationale,
            "recommended_actions": actions, "false_positives": false_positives,
            "input_requirements": inputs, "mitre": mitre,
            "threshold": threshold, "window_minutes": window_minutes}


RULES: dict[str, dict[str, Any]] = {
    "failed_login_burst": _rule(
        "failed_login_burst", "Repeated failed logins", "medium", [4625],
        "A concentrated burst of failures against one identity can indicate password guessing or a stale credential.",
        ("Review failure status/substatus, logon type, source endpoint, and targeted account.",
         "Check for subsequent successful logins and correlate with endpoint or VPN telemetry.",
         "Confirm whether a scheduled task or service has stale credentials; escalate suspicious activity."),
        ("Mistyped or expired passwords", "Scheduled tasks or services using stale credentials"),
        "4625 with timestamp, host, account, and source_ip. Domain is included when supplied.",
        (PASSWORD_GUESSING,), "At least 5 failures for the same host/domain/account/source in 5 minutes", 5),
    "password_spray": _rule(
        "password_spray", "Possible password spraying", "high", [4625],
        "Failures across several accounts from one source can indicate a password spray. Password values are not present in these logs.",
        ("Investigate the source IP and determine whether it belongs to an approved scanner, gateway, or service.",
         "Review successful authentications for affected accounts and correlate endpoint/authentication logs.",
         "Escalate if evidence supports unauthorized access; follow approved identity response procedures."),
        ("Shared NAT or authentication proxy", "Approved security testing", "Bulk stale credentials"),
        "4625 with timestamp, non-empty account, and non-empty source_ip; domain separates identities.",
        (PASSWORD_SPRAYING,), "At least 8 failures against 5 distinct domain/account identities from one source in 5 minutes", 5),
    "success_after_failures": _rule(
        "success_after_failures", "Successful login after repeated failures", "high", [4625, 4624],
        "A successful authentication after repeated failures merits validation of the user, source, and session. A corrected password is also possible.",
        ("Validate the authentication with the account owner and review its source and logon type.",
         "Review the successful session, privilege use, and endpoint activity after the login.",
         "Escalate when the session is unauthorized; preserve evidence before any response action."),
        ("A user corrects a mistyped or recently changed password", "A service retries with updated credentials"),
        "4625 and 4624 with timestamp, host, account, and source_ip; domain included when supplied. Host must match.",
        (PASSWORD_GUESSING,), "A success strictly after at least 5 matching failures within the preceding 10 minutes", 10),
    "new_user": _rule(
        "new_user", "New user account created", "medium", [4720],
        "Account creation should match an approved onboarding or administration request. The event alone does not show persistence.",
        ("Validate the target account, creating administrator, and approved change or onboarding request.",
         "Review initial logins, account properties, and subsequent group memberships.",
         "Escalate unexpected account creation to the identity administration team."),
        ("Approved onboarding", "Provisioning automation", "Test accounts in an authorized lab"),
        "4720. TargetUserName/account and SubjectUserName/subject_account enrich the investigation.",
        (CREATE_ACCOUNT,)),
    "privileged_group_change": _rule(
        "privileged_group_change", "Privileged group membership changed", "high", [4728, 4729, 4732, 4733, 4756, 4757],
        "Changes to recognized privileged groups alter access. Additions are high severity; removals are medium and receive no attack mapping.",
        ("Confirm the group, affected member, modifying administrator, and approved access request.",
         "Review the member's recent logins and privileged activity and verify least-privilege intent.",
         "Escalate unauthorized changes; coordinate any rollback with identity administrators."),
        ("Approved role changes", "Administrative cleanup", "Managed privileged-access workflows"),
        "A supported membership event plus group_name/TargetUserName or group_sid/TargetSid matching the documented privileged allowlist.",
        (GROUP_ADDITION,)),
    "suspicious_powershell": _rule(
        "suspicious_powershell", "Suspicious PowerShell indicators", "high", [4688, 4104],
        "Encoded commands, evaluation/downloader indicators, and defense-tampering markers warrant review. These lexical indicators are not a malware verdict.",
        ("Review the original command or script, executing identity, process lineage, and related endpoint activity.",
         "Validate whether the script belongs to approved administration or security testing.",
         "Decode suspicious content only in an approved analysis environment; never execute uploaded text."),
        ("Approved encoded automation", "Administrative scripts", "Authorized security tooling"),
        "4688 requires CommandLine and a powershell/pwsh process; 4104 requires ScriptBlockText. Process creation command-line auditing and PowerShell Script Block Logging must be enabled.",
        (POWERSHELL,)),
    "account_lockout": _rule(
        "account_lockout", "Account locked out", "medium", [4740],
        "An account lockout affects user access and may accompany repeated failures. A lockout alone is insufficient for an ATT&CK attribution.",
        ("Identify the locked account and CallerComputerName or source endpoint.",
         "Correlate preceding failures across domain controllers, services, and VPN logs.",
         "Validate stale credentials versus suspicious attempts and follow approved recovery procedures."),
        ("Stale credentials", "Repeated user password mistakes", "Misconfigured applications"),
        "4740; TargetUserName and CallerComputerName enrich the investigation."),
    "security_control_change": _rule(
        "security_control_change", "Security control changed", "medium", [1102, 4719, 4946, 4947, 4948, 5025],
        "Security log clearing and a stopped firewall are high severity. Audit-policy changes are medium unless the data explicitly records reduced auditing. Firewall rule changes are medium pending review.",
        ("Confirm the modifying identity, host, change details, and approved maintenance request.",
         "Compare the security configuration with the approved baseline and review adjacent administrative activity.",
         "Escalate unauthorized impairment; preserve remaining telemetry and coordinate restoration."),
        ("Approved maintenance", "Group Policy refresh", "Firewall or audit-policy administration"),
        "1102/5025 supported directly; 4719 AuditPolicyChanges/change can show removed auditing; 4946-4948 RuleName/RuleId enrich the finding.",
        (CLEAR_LOGS, AUDIT_REDUCTION, FIREWALL)),
}


def get_rule(rule_id: str) -> dict[str, Any]:
    return RULES[rule_id]


PRIVILEGED_GROUP_NAMES = frozenset({
    "administrators", "domain admins", "enterprise admins", "schema admins",
    "account operators", "server operators", "backup operators", "print operators",
    "group policy creator owners", "dnsadmins", "remote desktop users",
})
PRIVILEGED_BUILTIN_SIDS = frozenset({
    "S-1-5-32-544", "S-1-5-32-548", "S-1-5-32-549", "S-1-5-32-550",
    "S-1-5-32-551", "S-1-5-32-555",
})
PRIVILEGED_DOMAIN_RIDS = frozenset({"512", "518", "519", "520"})


def _detail(event: Event, *names: str) -> str:
    keys = {re.sub(r"[^a-z0-9]", "", str(key).casefold()): value for key, value in event.details.items()}
    for name in names:
        value = keys.get(re.sub(r"[^a-z0-9]", "", name.casefold()), "")
        if value is not None and str(value).strip():
            return str(value).strip()
    return ""


def _privileged_group(event: Event) -> bool:
    name = _detail(event, "group_name", "TargetUserName").casefold()
    short_name = name.rsplit("\\", 1)[-1]
    if short_name in PRIVILEGED_GROUP_NAMES:
        return True
    sid = _detail(event, "group_sid", "TargetSid", "TargetUserSid").upper()
    if sid in PRIVILEGED_BUILTIN_SIDS:
        return True
    return bool(re.fullmatch(r"S-1-5-21-\d+-\d+-\d+-(?:512|518|519|520)", sid))


POWERSHELL_INDICATORS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("encoded command", re.compile(r"-(?:enc|encodedcommand)\b", re.IGNORECASE)),
    ("execution-policy bypass", re.compile(r"-(?:ep|executionpolicy)\s+bypass\b", re.IGNORECASE)),
    ("expression evaluation", re.compile(r"\b(?:invoke-expression|iex)\b", re.IGNORECASE)),
    ("download-string invocation", re.compile(r"\bdownloadstring\b", re.IGNORECASE)),
    ("credential-access tooling marker", re.compile(r"\b(?:invoke-mimikatz|sekurlsa|invoke-credentialinjection)\b", re.IGNORECASE)),
    ("AMSI tampering marker", re.compile(r"\bamsiinitfailed\b", re.IGNORECASE)),
    ("real-time protection disablement", re.compile(r"set-mppreference[^\r\n]{0,200}-disablerealtimemonitoring\s+\$?true\b", re.IGNORECASE)),
)


def _powershell_indicators(event: Event) -> list[str]:
    if event.event_id == 4104:
        text = _detail(event, "script_block_text", "ScriptBlockText", "ScriptText", "Script")
    elif event.event_id == 4688:
        text = _detail(event, "command_line", "CommandLine", "ProcessCommandLine")
        process = _detail(event, "process_name", "NewProcessName", "Image", "ProcessName")
        if not text:
            return []
        if process:
            basename = re.split(r"[/\\]", process.strip('"'))[-1].casefold()
            if basename not in {"powershell.exe", "powershell", "pwsh.exe", "pwsh"}:
                return []
        elif not re.search(r"(?<![\w.-])(?:powershell|pwsh)(?:\.exe)?(?=\s|\"|'|$)", text, re.IGNORECASE):
            return []
    else:
        return []
    return [label for label, pattern in POWERSHELL_INDICATORS if pattern.search(text)]


def _audit_reduced(event: Event) -> bool:
    change = _detail(event, "change", "AuditPolicyChanges", "Changes", "PolicyChange", "ChangeType")
    return bool(re.search(r"%%(?:8448|8450)\b|\b(?:success|failure)\s+removed\b|\b(?:audit(?:ing)?\s+(?:disabled|removed)|disable(?:d)?\s+audit(?:ing)?)\b", change, re.IGNORECASE))


def _alert(rule_id: str, evidence: Iterable[Event], description: str,
           severity: str | None = None, title: str | None = None,
           mitre: tuple[Mapping[str, str], ...] | None = None,
           identity: str = "", anchor: Event | None = None) -> Alert:
    ordered = tuple(sorted(evidence, key=lambda event: (event.timestamp, event.id)))
    last = anchor or ordered[-1]
    rule = RULES[rule_id]
    # Anchor IDs remain stable when the same cumulative dataset is analyzed again.
    identifier = hashlib.sha256(f"{rule_id}|{identity}|{last.id}".encode("utf-8")).hexdigest()
    return Alert(
        id=identifier, rule_id=rule_id, title=title or rule["title"],
        severity=severity or rule["severity"], description=description,
        timestamp=last.timestamp, host=last.host, account=last.display_account,
        source_ip=last.source_ip, mitre=tuple(rule["mitre"] if mitre is None else mitre),
        evidence=ordered, recommended_actions=tuple(rule["recommended_actions"]),
        false_positives=tuple(rule["false_positives"]),
    )


def _authentication_key(event: Event) -> tuple[str, str, str, str]:
    return (event.host.casefold(), event.domain.casefold(), event.account.casefold(), event.source_ip.casefold())


def _correlations(events: list[Event]) -> list[Alert]:
    alerts: list[Alert] = []
    failures: dict[tuple[str, str, str, str], deque[Event]] = defaultdict(deque)
    bursts: dict[tuple[str, str, str, str], deque[Event]] = defaultdict(deque)
    sprays: dict[str, deque[Event]] = defaultdict(deque)
    spray_accounts: dict[str, Counter[tuple[str, str]]] = defaultdict(Counter)
    burst_last: dict[tuple[str, str, str, str], Event] = {}
    spray_last: dict[str, Event] = {}
    five_minutes, ten_minutes = timedelta(minutes=5), timedelta(minutes=10)
    for event in events:
        if event.event_id not in {4624, 4625}:
            continue
        key = _authentication_key(event)
        if event.host and event.account and event.source_ip:
            history = failures[key]
            while history and event.timestamp - history[0].timestamp > ten_minutes:
                history.popleft()
            if event.event_id == 4624:
                preceding = [item for item in history if item.timestamp < event.timestamp]
                if len(preceding) >= 5:
                    alerts.append(_alert("success_after_failures", preceding + [event],
                                         f"A successful login for {event.display_account} on {event.host} followed {len(preceding)} matching failed logins within 10 minutes from {event.source_ip}. Validate the session before judging whether access was unauthorized.",
                                         identity="|".join(key)))
                # A successful session closes the preceding retry sequence.
                # Subsequent successes should not repeatedly reuse old failures.
                history.clear()
                bursts[key].clear()
                burst_last.pop(key, None)
            else:
                history.append(event)
                recent = bursts[key]
                recent.append(event)
                while recent and event.timestamp - recent[0].timestamp > five_minutes:
                    recent.popleft()
                previous = burst_last.get(key)
                if len(recent) >= 5 and (previous is None or event.timestamp - previous.timestamp > five_minutes):
                    burst_last[key] = event
                    alerts.append(_alert("failed_login_burst", recent,
                                         f"Observed {len(recent)} failed logins for {event.display_account} on {event.host} from {event.source_ip} within 5 minutes. This pattern can reflect guessing or stale credentials.",
                                         identity="|".join(key)))
        if event.event_id == 4625 and event.account and event.source_ip:
            source = event.source_ip.casefold()
            window = sprays[source]
            identities = spray_accounts[source]
            window.append(event)
            identities[(event.domain.casefold(), event.account.casefold())] += 1
            while window and event.timestamp - window[0].timestamp > five_minutes:
                expired = window.popleft()
                identity = (expired.domain.casefold(), expired.account.casefold())
                identities[identity] -= 1
                if not identities[identity]:
                    del identities[identity]
            previous = spray_last.get(source)
            if len(window) >= 8 and len(identities) >= 5 and (previous is None or event.timestamp - previous.timestamp > five_minutes):
                spray_last[source] = event
                alerts.append(_alert("password_spray", window,
                                     f"Observed {len(window)} failed logins against {len(identities)} distinct account identities from {source} within 5 minutes. Password values are unavailable; investigate this as a possible spray.",
                                     identity=source))
    return alerts


def _single_events(events: list[Event]) -> list[Alert]:
    alerts: list[Alert] = []
    for event in events:
        if event.event_id == 4720:
            actor = _detail(event, "subject_account", "SubjectUserName") or "an unspecified administrator"
            alerts.append(_alert("new_user", [event],
                                 f"Account {event.display_account or '(not supplied)'} was created on {event.host or '(host not supplied)'} by {actor}. Verify the approved provisioning request."))
        elif event.event_id in {4728, 4729, 4732, 4733, 4756, 4757} and _privileged_group(event):
            added = event.event_id in {4728, 4732, 4756}
            group = _detail(event, "group_name", "TargetUserName", "group_sid", "TargetSid")
            member = _detail(event, "member_name", "MemberName", "member_sid", "MemberSid") or event.account or "an unspecified member"
            action = "added to" if added else "removed from"
            alerts.append(_alert("privileged_group_change", [event],
                                 f"{member} was {action} recognized privileged group {group} on {event.host or '(host not supplied)'}. Validate the access change and modifying identity.",
                                 severity="high" if added else "medium", title="Privileged group member added" if added else "Privileged group member removed",
                                 mitre=(GROUP_ADDITION,) if added else ()))
        elif event.event_id in {4688, 4104}:
            indicators = _powershell_indicators(event)
            if indicators:
                alerts.append(_alert("suspicious_powershell", [event],
                                     f"PowerShell content on {event.host or '(host not supplied)'} contains these indicators: {', '.join(indicators)}. Review the original evidence and approved automation context; lexical matches do not establish malicious intent."))
        elif event.event_id == 4740:
            caller = _detail(event, "caller_computer", "CallerComputerName")
            alerts.append(_alert("account_lockout", [event],
                                 f"Account {event.display_account or '(not supplied)'} was locked out on {event.host or '(host not supplied)'}. Caller computer: {caller or '(not supplied)'}. Correlate preceding failures before attributing a cause."))
        elif event.event_id in {1102, 4719, 4946, 4947, 4948, 5025}:
            if event.event_id == 1102:
                title, severity, mapping = "Windows Security log cleared", "high", (CLEAR_LOGS,)
                text = "The Windows Security audit log was cleared. Validate maintenance authorization and preserve remaining telemetry."
            elif event.event_id == 5025:
                title, severity, mapping = "Windows Firewall service stopped", "high", (FIREWALL,)
                text = "The Windows Firewall service stopped. Validate service maintenance and review the host's current protection state."
            elif event.event_id == 4719:
                reduced = _audit_reduced(event)
                title = "Audit policy coverage reduced" if reduced else "Audit policy changed"
                severity, mapping = ("high", (AUDIT_REDUCTION,)) if reduced else ("medium", ())
                change = _detail(event, "change", "AuditPolicyChanges")
                text = f"System audit policy changed. Reported change: {change or '(change details not supplied)'}. "
                text += "The supplied change explicitly removes audit coverage." if reduced else "The event alone does not establish reduced protection; compare with the approved baseline."
            else:
                action = {4946: "added", 4947: "modified", 4948: "deleted"}[event.event_id]
                title, severity, mapping = f"Windows Firewall rule {action}", "medium", (FIREWALL,)
                rule = _detail(event, "rule_name", "RuleName", "rule_id", "RuleId") or "(not supplied)"
                text = f"A Windows Firewall rule was {action}: {rule}. Validate the change and its effect on permitted traffic; the event does not by itself show weakened protection."
            alerts.append(_alert("security_control_change", [event], text, severity=severity, title=title, mitre=mapping))
    return alerts


def detect(events: Iterable[Event]) -> list[Alert]:
    """Analyze a cumulative dataset, deduplicating and sorting deterministically.

    Burst and spray findings use a five-minute per-identity/source cooldown to
    avoid one finding for every subsequent failure in the same window. Evidence
    is the complete qualifying window at the trigger; later failures remain
    searchable events. Authentication success requires an exact host match.
    """
    ordered = sorted({event.id: event for event in events}.values(), key=lambda event: (event.timestamp, event.id))
    alerts = _correlations(ordered) + _single_events(ordered)
    rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    newest_first = sorted({alert.id: alert for alert in alerts}.values(),
                          key=lambda alert: (alert.timestamp, alert.id), reverse=True)
    return sorted(newest_first, key=lambda alert: rank[alert.severity])


detect_events = detect
