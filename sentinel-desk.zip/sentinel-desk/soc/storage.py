"""SQLite persistence, atomic imports, and durable analyst decisions."""
import json
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timezone

from .models import Event
from .detections import detect

STATUSES = ("New", "Investigating", "Closed — benign", "Closed — escalated")
MAX_EVENTS = 25000


@contextmanager
def connection(path):
    db = sqlite3.connect(str(path), timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys = ON")
    try:
        yield db
    finally:
        db.close()


def initialize(path):
    with connection(path) as db:
        db.executescript("""
        CREATE TABLE IF NOT EXISTS events (
          id TEXT PRIMARY KEY, timestamp TEXT NOT NULL, event_id INTEGER NOT NULL,
          host TEXT NOT NULL, account TEXT NOT NULL, source_ip TEXT NOT NULL,
          payload TEXT NOT NULL);
        CREATE INDEX IF NOT EXISTS event_time ON events(timestamp);
        CREATE TABLE IF NOT EXISTS alerts (
          id TEXT PRIMARY KEY, rule_id TEXT NOT NULL, title TEXT NOT NULL,
          severity TEXT NOT NULL, timestamp TEXT NOT NULL, host TEXT NOT NULL,
          account TEXT NOT NULL, source_ip TEXT NOT NULL, payload TEXT NOT NULL,
          status TEXT NOT NULL DEFAULT 'New');
        CREATE TABLE IF NOT EXISTS notes (
          id INTEGER PRIMARY KEY, alert_id TEXT NOT NULL REFERENCES alerts(id),
          timestamp TEXT NOT NULL, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS activity (
          id INTEGER PRIMARY KEY, alert_id TEXT NOT NULL REFERENCES alerts(id),
          timestamp TEXT NOT NULL, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS imports (
          id INTEGER PRIMARY KEY, timestamp TEXT NOT NULL, source TEXT NOT NULL,
          received INTEGER NOT NULL, inserted INTEGER NOT NULL, alerts_added INTEGER NOT NULL);
        """)
        db.commit()


def now():
    return datetime.now(timezone.utc).isoformat()


def import_events(path, events, source):
    """All rows and resulting detections commit together; duplicates preserve triage."""
    with connection(path) as db:
        db.execute("BEGIN IMMEDIATE")
        old_count = db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0]
        inserted = 0
        for event in events:
            inserted += db.execute(
                "INSERT OR IGNORE INTO events VALUES (?,?,?,?,?,?,?)",
                (event.id, event.timestamp.isoformat(), event.event_id, event.host,
                 event.account, event.source_ip, json.dumps(event.to_dict()))).rowcount
        if db.execute("SELECT COUNT(*) FROM events").fetchone()[0] > MAX_EVENTS:
            raise ValueError(f"Demo storage limit is {MAX_EVENTS:,} unique events. Use a fresh database for another dataset.")
        all_events = [Event.from_dict(json.loads(r[0])) for r in db.execute("SELECT payload FROM events ORDER BY timestamp,id")]
        for alert in detect(all_events):
            db.execute(
                "INSERT INTO alerts(id,rule_id,title,severity,timestamp,host,account,source_ip,payload) "
                "VALUES(?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload",
                (alert.id, alert.rule_id, alert.title, alert.severity, alert.timestamp.isoformat(),
                 alert.host, alert.account, alert.source_ip, json.dumps(alert.to_dict()))).rowcount
        alerts_added = db.execute("SELECT COUNT(*) FROM alerts").fetchone()[0] - old_count
        db.execute("INSERT INTO imports(timestamp,source,received,inserted,alerts_added) VALUES(?,?,?,?,?)",
                   (now(), source, len(events), inserted, alerts_added))
        db.commit()
    return {"received": len(events), "inserted": inserted, "duplicates": len(events) - inserted, "alerts_added": alerts_added}


def escape_like(text):
    return "%" + text.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"


def list_alerts(path, severity="", status="", query="", page=1, per_page=20):
    clauses, params = [], []
    if severity:
        clauses.append("severity=?")
        params.append(severity)
    if status:
        clauses.append("status=?")
        params.append(status)
    if query:
        clauses.append("(title LIKE ? ESCAPE '\\' OR host LIKE ? ESCAPE '\\' OR account LIKE ? ESCAPE '\\' OR source_ip LIKE ? ESCAPE '\\')")
        params.extend([escape_like(query)] * 4)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with connection(path) as db:
        total = db.execute("SELECT COUNT(*) FROM alerts" + where, params).fetchone()[0]
        rows = db.execute("SELECT * FROM alerts" + where +
            " ORDER BY CASE severity WHEN 'critical' THEN 0 WHEN 'high' THEN 1 WHEN 'medium' THEN 2 ELSE 3 END, timestamp DESC,id LIMIT ? OFFSET ?",
            params + [per_page, (page - 1) * per_page]).fetchall()
        return [dict(row) for row in rows], total


def get_alert(path, alert_id):
    with connection(path) as db:
        row = db.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone()
        if row is None:
            return None
        alert = json.loads(row["payload"])
        alert["status"] = row["status"]
        alert["notes"] = [dict(r) for r in db.execute("SELECT * FROM notes WHERE alert_id=? ORDER BY id", (alert_id,))]
        alert["activity"] = [dict(r) for r in db.execute("SELECT * FROM activity WHERE alert_id=? ORDER BY id", (alert_id,))]
        return alert


def update_investigation(path, alert_id, status, note):
    if status not in STATUSES:
        raise ValueError("Select a valid investigation status.")
    if len(note) > 4000:
        raise ValueError("Analyst notes must be 4,000 characters or fewer.")
    with connection(path) as db:
        db.execute("BEGIN IMMEDIATE")
        row = db.execute("SELECT status FROM alerts WHERE id=?", (alert_id,)).fetchone()
        if row is None:
            raise LookupError("Alert not found.")
        if row[0] != status:
            db.execute("UPDATE alerts SET status=? WHERE id=?", (status, alert_id))
            db.execute("INSERT INTO activity(alert_id,timestamp,body) VALUES(?,?,?)", (alert_id, now(), f"Status: {row[0]} → {status}"))
        if note.strip():
            db.execute("INSERT INTO notes(alert_id,timestamp,body) VALUES(?,?,?)", (alert_id, now(), note.strip()))
        db.commit()


def search_events(path, query="", event_id="", host="", start="", end="", page=1, per_page=30):
    clauses, params = [], []
    if query:
        clauses.append("payload LIKE ? ESCAPE '\\'")
        params.append(escape_like(query))
    for field, value in (("event_id", event_id), ("host", host)):
        if value != "":
            clauses.append(field + "=?")
            params.append(value)
    for operator, value in ((">=", start), ("<=", end)):
        if value:
            clauses.append("timestamp" + operator + "?")
            params.append(value)
    where = " WHERE " + " AND ".join(clauses) if clauses else ""
    with connection(path) as db:
        total = db.execute("SELECT COUNT(*) FROM events" + where, params).fetchone()[0]
        rows = db.execute("SELECT payload FROM events" + where + " ORDER BY timestamp DESC,id LIMIT ? OFFSET ?",
                          params + [per_page, (page - 1) * per_page]).fetchall()
        return [json.loads(row[0]) for row in rows], total


def dashboard(path):
    with connection(path) as db:
        metrics = {"events": db.execute("SELECT COUNT(*) FROM events").fetchone()[0],
                   "open_alerts": db.execute("SELECT COUNT(*) FROM alerts WHERE status IN ('New','Investigating')").fetchone()[0],
                   "high_priority": db.execute("SELECT COUNT(*) FROM alerts WHERE severity IN ('high','critical') AND status IN ('New','Investigating')").fetchone()[0],
                   "hosts": db.execute("SELECT COUNT(DISTINCT host) FROM events WHERE host<>''").fetchone()[0]}
        metrics["range"] = db.execute("SELECT MIN(timestamp),MAX(timestamp) FROM events").fetchone()
        metrics["severities"] = {r[0]: r[1] for r in db.execute("SELECT severity,COUNT(*) FROM alerts GROUP BY severity")}
        metrics["imports"] = [dict(r) for r in db.execute("SELECT * FROM imports ORDER BY id DESC LIMIT 4")]
        metrics["timeline"] = [dict(r) for r in db.execute(
            "SELECT substr(timestamp,1,13) AS hour, COUNT(*) AS count FROM events GROUP BY hour ORDER BY hour DESC LIMIT 24")][::-1]
        metrics["event_types"] = [dict(r) for r in db.execute("SELECT event_id,COUNT(*) AS count FROM events GROUP BY event_id ORDER BY count DESC LIMIT 6")]
    return metrics
