"use strict";
// Native controls keep the entire analyst workflow usable without JavaScript.
document.querySelectorAll('form[method="post"]').forEach((form) => {
  form.addEventListener("submit", () => {
    const button = form.querySelector('button[type="submit"], button:not([type])');
    if (button && form.checkValidity()) {
      button.disabled = true;
      button.textContent = "Saving…";
    }
  });
});
