"""Immutable, JSON-serializable records shared by ingestion and detections."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from types import MappingProxyType
from typing import Any, Mapping


def _freeze(value: Any) -> Any:
    if isinstance(value, Mapping):
        return MappingProxyType({str(key): _freeze(item) for key, item in value.items()})
    if isinstance(value, (list, tuple)):
        return tuple(_freeze(item) for item in value)
    return value


def _thaw(value: Any) -> Any:
    if isinstance(value, Mapping):
        return {str(key): _thaw(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_thaw(item) for item in value]
    return value


def _utc(value: datetime) -> datetime:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("Record timestamps must be timezone-aware datetime values.")
    return value.astimezone(timezone.utc)


def _datetime(value: str) -> datetime:
    return _utc(datetime.fromisoformat(value.replace("Z", "+00:00")))


@dataclass(frozen=True)
class Event:
    id: str
    timestamp: datetime
    event_id: int
    host: str = ""
    account: str = ""
    domain: str = ""
    source_ip: str = ""
    details: Mapping[str, Any] = field(default_factory=dict)
    raw: Mapping[str, Any] = field(default_factory=dict, repr=False, compare=False)

    def __post_init__(self) -> None:
        object.__setattr__(self, "timestamp", _utc(self.timestamp))
        object.__setattr__(self, "details", _freeze(self.details))
        object.__setattr__(self, "raw", _freeze(self.raw))

    @property
    def display_account(self) -> str:
        return f"{self.domain}\\{self.account}" if self.domain and self.account else self.account

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "timestamp": self.timestamp.isoformat(), "event_id": self.event_id,
            "host": self.host, "account": self.account, "domain": self.domain,
            "source_ip": self.source_ip, "details": _thaw(self.details), "raw": _thaw(self.raw),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> Event:
        return cls(
            id=str(value["id"]), timestamp=_datetime(str(value["timestamp"])),
            event_id=int(value["event_id"]), host=str(value.get("host", "")),
            account=str(value.get("account", "")), domain=str(value.get("domain", "")),
            source_ip=str(value.get("source_ip", "")), details=value.get("details", {}),
            raw=value.get("raw", {}),
        )


@dataclass(frozen=True)
class Alert:
    id: str
    rule_id: str
    title: str
    severity: str
    description: str
    timestamp: datetime
    host: str
    account: str
    source_ip: str
    mitre: tuple[Mapping[str, str], ...]
    evidence: tuple[Event, ...]
    recommended_actions: tuple[str, ...]
    false_positives: tuple[str, ...]

    def __post_init__(self) -> None:
        if self.severity not in {"low", "medium", "high", "critical"}:
            raise ValueError(f"Unsupported alert severity: {self.severity}")
        object.__setattr__(self, "timestamp", _utc(self.timestamp))
        object.__setattr__(self, "mitre", tuple(_freeze(item) for item in self.mitre))
        object.__setattr__(self, "evidence", tuple(self.evidence))
        object.__setattr__(self, "recommended_actions", tuple(self.recommended_actions))
        object.__setattr__(self, "false_positives", tuple(self.false_positives))

    @property
    def evidence_ids(self) -> tuple[str, ...]:
        return tuple(event.id for event in self.evidence)

    @property
    def timeline(self) -> tuple[Event, ...]:
        return tuple(sorted(self.evidence, key=lambda event: (event.timestamp, event.id)))

    def to_dict(self) -> dict[str, Any]:
        return {
            "id": self.id, "rule_id": self.rule_id, "title": self.title,
            "severity": self.severity, "description": self.description,
            "timestamp": self.timestamp.isoformat(), "host": self.host,
            "account": self.account, "source_ip": self.source_ip, "mitre": _thaw(self.mitre),
            "evidence": [event.to_dict() for event in self.evidence],
            "evidence_ids": list(self.evidence_ids),
            "recommended_actions": list(self.recommended_actions),
            "false_positives": list(self.false_positives),
        }

    @classmethod
    def from_dict(cls, value: Mapping[str, Any]) -> Alert:
        return cls(
            id=str(value["id"]), rule_id=str(value["rule_id"]), title=str(value["title"]),
            severity=str(value["severity"]), description=str(value["description"]),
            timestamp=_datetime(str(value["timestamp"])), host=str(value.get("host", "")),
            account=str(value.get("account", "")), source_ip=str(value.get("source_ip", "")),
            mitre=tuple(value.get("mitre", [])),
            evidence=tuple(Event.from_dict(item) for item in value.get("evidence", [])),
            recommended_actions=tuple(value.get("recommended_actions", [])),
            false_positives=tuple(value.get("false_positives", [])),
        )
