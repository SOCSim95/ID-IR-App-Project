"""Read views and CSRF-protected local analyst workflows."""
import hmac
import math
import secrets
from datetime import datetime, timezone
from urllib.parse import urlencode

from flask import Blueprint, abort, current_app, flash, jsonify, redirect, render_template, request, session, url_for

from . import storage
from .detections import RULES
from .ingestion import IngestionError, read_events

bp = Blueprint("main", __name__)
SEVERITIES = ("critical", "high", "medium", "low")


def db_path():
    return current_app.config["DATABASE"]


def page_number():
    try:
        return max(1, min(int(request.args.get("page", 1)), 10000))
    except ValueError:
        return 1


@bp.app_context_processor
def context():
    session.setdefault("csrf_token", secrets.token_hex(32))
    return {"csrf_token": session["csrf_token"], "statuses": storage.STATUSES, "severities": SEVERITIES}


@bp.before_app_request
def protect_writes():
    if request.method == "POST":
        token = request.form.get("csrf_token", "")
        expected = session.get("csrf_token", "")
        if not expected or not hmac.compare_digest(expected, token):
            abort(400, description="The form expired. Reload the page and try again.")


@bp.after_app_request
def security_headers(response):
    response.headers["Content-Security-Policy"] = "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Cache-Control"] = "no-store"
    return response


@bp.app_template_filter("utc")
def utc(value):
    if not value:
        return "—"
    try:
        return datetime.fromisoformat(str(value).replace("Z", "+00:00")).strftime("%b %d · %H:%M:%S")
    except ValueError:
        return str(value)


@bp.app_template_filter("page_query")
def page_query(arguments, page):
    return urlencode({**arguments, "page": page})


@bp.get("/")
def dashboard():
    data = storage.dashboard(db_path())
    alerts, _ = storage.list_alerts(db_path(), status="New", per_page=5)
    return render_template("dashboard.html", metrics=data, alerts=alerts, active="dashboard", title="Overview")


@bp.get("/alerts")
def alerts():
    severity, status = request.args.get("severity", ""), request.args.get("status", "")
    if severity and severity not in SEVERITIES or status and status not in storage.STATUSES:
        abort(400, description="Invalid alert filter.")
    query = request.args.get("q", "")[:200]
    page = page_number()
    rows, total = storage.list_alerts(db_path(), severity, status, query, page)
    return render_template("alerts.html", alerts=rows, total=total, page=page, pages=math.ceil(total / 20),
                           severity=severity, status=status, query=query, active="alerts", title="Alert queue")


@bp.route("/alerts/<alert_id>", methods=["GET", "POST"])
def investigation(alert_id):
    alert = storage.get_alert(db_path(), alert_id)
    if alert is None:
        abort(404)
    if request.method == "POST":
        try:
            storage.update_investigation(db_path(), alert_id, request.form.get("status", ""), request.form.get("note", ""))
        except ValueError as exc:
            flash(str(exc), "error")
        else:
            flash("Investigation saved.", "success")
        return redirect(url_for("main.investigation", alert_id=alert_id))
    return render_template("investigation.html", alert=alert, active="alerts", title="Investigation")


@bp.get("/events")
def events():
    query, host = request.args.get("q", "")[:200], request.args.get("host", "")[:200]
    event_id = request.args.get("event_id", "")
    start, end = request.args.get("start", ""), request.args.get("end", "")
    try:
        if event_id:
            event_id = int(event_id)
        # datetime-local controls are explicitly labelled UTC.
        bounds = [datetime.fromisoformat(v).replace(tzinfo=timezone.utc).isoformat() if v else "" for v in (start, end)]
        if all(bounds) and bounds[0] > bounds[1]:
            raise ValueError
    except ValueError:
        abort(400, description="Use a numeric Event ID and an ordered UTC date range.")
    page = page_number()
    rows, total = storage.search_events(db_path(), query, event_id, host, *bounds, page=page)
    return render_template("events.html", events=rows, total=total, page=page, pages=math.ceil(total / 30),
                           query=query, host=host, event_id=event_id, start=start, end=end, active="events", title="Event search")


@bp.get("/rules")
def rules():
    return render_template("rules.html", rules=RULES, active="rules", title="Detection rules")


@bp.route("/import", methods=["GET", "POST"])
def import_logs():
    if request.method == "POST":
        upload = request.files.get("file")
        if upload is None or not upload.filename:
            flash("Choose a CSV or JSON file.", "error")
        else:
            try:
                records = read_events(upload.read(), upload.filename, request.form.get("timezone") or None)
                result = storage.import_events(db_path(), records, upload.filename.replace("\\", "/").rsplit("/", 1)[-1][:200])
            except (IngestionError, ValueError) as exc:
                flash(str(exc), "error")
            else:
                flash(f"Imported {result['inserted']} new events · {result['duplicates']} duplicates · {result['alerts_added']} new alerts.", "success")
                return redirect(url_for("main.dashboard"))
        return redirect(url_for("main.import_logs"))
    return render_template("import.html", active="import", title="Import events")


@bp.get("/health")
def health():
    return jsonify(status="ok", events=storage.dashboard(db_path())["events"])


@bp.app_errorhandler(400)
@bp.app_errorhandler(404)
@bp.app_errorhandler(413)
def error(error):
    # Host validation happens before a URL adapter exists. Avoid rendering links.
    if request.routing_exception is not None and request.url_rule is None and error.code == 400:
        return "Invalid request host.", 400
    message = "File exceeds the 5 MB upload limit." if error.code == 413 else error.description
    return render_template("error.html", code=error.code, message=message, title="Request unavailable", active=""), error.code
