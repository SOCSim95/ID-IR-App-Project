"""Application factory for the local SOC portfolio dashboard."""
import os
import secrets
from pathlib import Path

import click
from flask import Flask

from . import storage
from .ingestion import read_events, IngestionError


def create_app(test_config=None):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_mapping(
        DATABASE=os.environ.get("SOC_DATABASE", str(Path(app.instance_path) / "soc.db")),
        MAX_CONTENT_LENGTH=5 * 1024 * 1024,
        MAX_FORM_MEMORY_SIZE=100_000,
        AUTO_SEED=os.environ.get("SOC_AUTO_DEMO", "1") != "0",
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Strict",
        TRUSTED_HOSTS=["localhost", "127.0.0.1", "[::1]"],
    )
    if test_config:
        app.config.update(test_config)
    Path(app.instance_path).mkdir(parents=True, exist_ok=True)
    if not app.config.get("SECRET_KEY"):
        app.config["SECRET_KEY"] = os.environ.get("SOC_SECRET_KEY") or _local_secret(Path(app.instance_path) / "session.key")
    Path(app.config["DATABASE"]).parent.mkdir(parents=True, exist_ok=True)
    storage.initialize(app.config["DATABASE"])
    sample = Path(app.root_path).parent / "sample_data" / "demo_events.json"
    if app.config["AUTO_SEED"] and storage.dashboard(app.config["DATABASE"])["events"] == 0 and sample.exists():
        storage.import_events(app.config["DATABASE"], read_events(sample.read_bytes(), sample.name), "Synthetic demo")

    from .routes import bp
    app.register_blueprint(bp)

    @app.cli.command("import-logs")
    @click.argument("path", type=click.Path(exists=True, dir_okay=False, path_type=Path))
    @click.option("--assume-timezone", default=None, help="Explicit timezone for naive exports: UTC or +HH:MM.")
    def import_logs(path, assume_timezone):
        """Import a supported CSV/JSON export atomically."""
        if path.stat().st_size > app.config["MAX_CONTENT_LENGTH"]:
            raise click.ClickException("File exceeds the 5 MB import limit.")
        try:
            result = storage.import_events(app.config["DATABASE"], read_events(path.read_bytes(), path.name, assume_timezone), path.name)
        except (IngestionError, ValueError) as exc:
            raise click.ClickException(str(exc)) from exc
        click.echo(f"Imported {result['inserted']} new events; {result['duplicates']} duplicates; {result['alerts_added']} new alerts.")

    @app.cli.command("load-demo")
    def load_demo():
        """Load synthetic activity without overwriting analyst decisions."""
        result = storage.import_events(app.config["DATABASE"], read_events(sample.read_bytes(), sample.name), "Synthetic demo")
        click.echo(f"Loaded {result['inserted']} new events; {result['alerts_added']} new alerts.")

    return app


def _local_secret(path):
    """Generate a per-install key; never ship a shared development secret."""
    try:
        with path.open("x", encoding="ascii") as handle:
            handle.write(secrets.token_hex(32))
        # On Unix this enforces user-only access; on Windows inherit the user's ACL.
        path.chmod(0o600)
    except FileExistsError:
        pass
    return path.read_text(encoding="ascii").strip()
