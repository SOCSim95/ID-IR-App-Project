"""Validate CSV/JSON exports and normalize common Windows Event field shapes.

No uploaded text is executed. All input is parsed as data. Ambiguous local times
are rejected unless the caller explicitly supplies a fixed timezone assumption.
"""

from __future__ import annotations

import csv
import hashlib
import io
import ipaddress
import json
import math
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

from .models import Event

MAX_RECORDS = 20_000
MAX_CONTENT_BYTES = 10 * 1024 * 1024


class IngestionError(ValueError):
    """An actionable validation error safe to show beside an upload form."""


def _validate_shape(value: Any, depth: int = 0) -> None:
    if depth > 32:
        raise IngestionError("Event data is nested too deeply. Flatten the export to System/EventData or canonical fields.")
    if isinstance(value, Mapping):
        for key, item in value.items():
            if not isinstance(key, str):
                raise IngestionError("Event field names must be strings.")
            _validate_shape(key, depth + 1)
            _validate_shape(item, depth + 1)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _validate_shape(item, depth + 1)
    elif isinstance(value, str):
        try:
            value.encode("utf-8")
        except UnicodeEncodeError as exc:
            raise IngestionError("Event data contains invalid Unicode. Export valid UTF-8 text and try again.") from exc
    elif isinstance(value, float) and not math.isfinite(value):
        raise IngestionError("Event data contains a non-finite number. Use valid JSON numbers.")
    elif value is not None and not isinstance(value, (int, float, bool)):
        raise IngestionError("Event data must contain JSON-compatible field values.")


def _key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(value).casefold())


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, Mapping):
        for name in ("#text", "text", "value", "Value", "SystemTime", "@SystemTime"):
            if name in value:
                return _text(value[name])
        return ""
    result = str(value).strip()
    return "" if result.casefold() in {"-", "n/a", "null", "none"} else result


def _named_data(value: Any) -> dict[str, Any]:
    """Support EventData dicts and XML-to-JSON Data Name/text arrays."""
    if isinstance(value, Mapping):
        if "Data" in value:
            return _named_data(value["Data"])
        name = value.get("Name", value.get("@Name"))
        if name:
            return {str(name): value.get("#text", value.get("text", value.get("Value", "")))}
        return dict(value)
    if isinstance(value, list):
        result: dict[str, Any] = {}
        for item in value:
            result.update(_named_data(item))
        return result
    if isinstance(value, str) and value.strip().startswith(("{", "[")):
        try:
            parsed_data = json.loads(value)
            _validate_shape(parsed_data)
            return _named_data(parsed_data)
        except (json.JSONDecodeError, RecursionError) as exc:
            raise IngestionError("EventData/details contains invalid JSON. Use a JSON object or named Data array.") from exc
    return {}


def _fields(record: Mapping[str, Any]) -> dict[str, Any]:
    event_root = record.get("Event", record)
    if not isinstance(event_root, Mapping):
        raise IngestionError("Event must contain an object with System and EventData fields.")
    merged: dict[str, Any] = {}
    system = event_root.get("System", {})
    if isinstance(system, Mapping):
        merged.update(system)
    for name in ("EventData", "event_data", "details"):
        merged.update(_named_data(event_root.get(name)))
    # Explicit flat fields take precedence over nested aliases.
    merged.update({name: value for name, value in event_root.items() if name not in {"System", "EventData", "event_data", "details"}})
    return {_key(name): value for name, value in merged.items()}


def _first(fields: Mapping[str, Any], *names: str) -> str:
    for name in names:
        value = _text(fields.get(_key(name)))
        if value:
            return value
    return ""


def _timestamp(value: str, assumption: str | None) -> datetime:
    if not value:
        raise IngestionError("Missing timestamp. Provide timestamp or TimeCreated.SystemTime in ISO 8601 format.")
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00").replace("z", "+00:00"))
    except ValueError as exc:
        raise IngestionError(f"Invalid timestamp '{value[:100]}'. Use ISO 8601, for example 2026-10-07T14:00:00Z.") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        if not assumption:
            raise IngestionError("Timestamp has no timezone. Export an ISO 8601 UTC/offset timestamp, or explicitly set assume_timezone='UTC'.")
        if assumption.upper() in {"UTC", "Z"}:
            assumed_zone = timezone.utc
        elif re.fullmatch(r"[+-]\d{2}:\d{2}", assumption):
            hours, minutes = map(int, assumption[1:].split(":"))
            if hours > 23 or minutes > 59:
                raise IngestionError("assume_timezone must be UTC or a valid fixed offset such as -04:00.")
            offset = timedelta(hours=hours, minutes=minutes)
            assumed_zone = timezone(offset if assumption[0] == "+" else -offset)
        else:
            raise IngestionError("assume_timezone must be UTC or a fixed offset such as -04:00; regional DST zones are not inferred.")
        parsed = parsed.replace(tzinfo=assumed_zone)
    try:
        return parsed.astimezone(timezone.utc)
    except (ValueError, OverflowError) as exc:
        raise IngestionError("Timestamp falls outside the supported date range after conversion to UTC.") from exc


DETAIL_ALIASES: dict[str, tuple[str, ...]] = {
    "subject_account": ("subject_account", "SubjectUserName"),
    "subject_domain": ("subject_domain", "SubjectDomainName"),
    "subject_sid": ("subject_sid", "SubjectUserSid"),
    "target_sid": ("target_sid", "TargetUserSid", "TargetSid"),
    "group_name": ("group_name", "GroupName"),
    "group_sid": ("group_sid", "GroupSid"),
    "member_name": ("member_name", "MemberName"),
    "member_sid": ("member_sid", "MemberSid"),
    "command_line": ("command_line", "CommandLine", "ProcessCommandLine"),
    "process_name": ("process_name", "NewProcessName", "Image", "ProcessName"),
    "parent_process": ("parent_process", "ParentProcessName", "CreatorProcessName"),
    "script_block_text": ("script_block_text", "ScriptBlockText", "ScriptText", "Script"),
    "script_block_id": ("script_block_id", "ScriptBlockId"),
    "change": ("change", "AuditPolicyChanges", "Changes", "PolicyChange", "ChangeType"),
    "category": ("category", "CategoryId"),
    "subcategory": ("subcategory", "SubcategoryId", "SubcategoryGuid"),
    "logon_type": ("logon_type", "LogonType"),
    "status": ("status", "Status", "FailureReason"),
    "substatus": ("substatus", "SubStatus"),
    "caller_computer": ("caller_computer", "CallerComputerName", "WorkstationName"),
    "rule_name": ("rule_name", "RuleName"),
    "rule_id": ("rule_id", "RuleId"),
    "provider": ("provider", "ProviderName"),
    "channel": ("channel", "Channel"),
    "event_record_id": ("event_record_id", "EventRecordID", "RecordId", "RecordNumber"),
}


def normalize_event(record: Mapping[str, Any], assume_timezone: str | None = None) -> Event:
    if not isinstance(record, Mapping):
        raise IngestionError("Each event must be a JSON object or CSV row.")
    _validate_shape(record)
    fields = _fields(record)
    value = _first(fields, "event_id", "EventID", "Id", "EventCode")
    try:
        if not re.fullmatch(r"\d{1,6}", value):
            raise ValueError
        event_id = int(value)
        if not 0 <= event_id <= 65535:
            raise ValueError
    except ValueError as exc:
        raise IngestionError("Missing or invalid event_id. Provide a Windows EventID integer between 0 and 65535.") from exc
    timestamp = _timestamp(_first(fields, "timestamp", "TimeCreated", "SystemTime", "TimeGenerated", "@timestamp", "DateTime"), assume_timezone)
    host = _first(fields, "host", "computer", "ComputerName", "Hostname", "MachineName").casefold()
    account = _first(fields, "account", "target_account", "TargetUserName", "UserName", "User", "SubjectUserName")
    domain = _first(fields, "domain", "TargetDomainName", "AccountDomain")
    if "\\" in account:
        account_domain, account = account.rsplit("\\", 1)
        if not domain:
            domain = account_domain
    elif "@" in account:
        account, account_domain = account.rsplit("@", 1)
        if not domain:
            domain = account_domain
    if account and not domain and account.casefold() == _first(fields, "SubjectUserName", "subject_account").casefold():
        domain = _first(fields, "SubjectDomainName", "subject_domain")
    source_ip = _first(fields, "source_ip", "IpAddress", "SourceNetworkAddress", "SourceIP", "ClientAddress", "ClientIP")
    try:
        ip = ipaddress.ip_address(source_ip)
        source_ip = str(ip.ipv4_mapped if isinstance(ip, ipaddress.IPv6Address) and ip.ipv4_mapped else ip)
    except ValueError:
        pass
    details = {name: _first(fields, *aliases) for name, aliases in DETAIL_ALIASES.items()}
    details = {name: value for name, value in details.items() if value}
    if event_id in {4728, 4729, 4732, 4733, 4756, 4757}:
        details.setdefault("group_name", _first(fields, "TargetUserName"))
        details.setdefault("group_sid", _first(fields, "TargetSid", "TargetUserSid"))
        # TargetSid identifies the group on membership events; retaining a
        # second target_sid alias would make equivalent export shapes hash
        # differently even though their normalized information is identical.
        details.pop("target_sid", None)
        member = _first(fields, "member_name", "MemberName", "member_sid", "MemberSid")
        if member:
            account = member
            if "\\" in member:
                domain, account = member.rsplit("\\", 1)
            elif "@" in member:
                account, domain = member.rsplit("@", 1)
    # Normalize identity-like values only. Commands/scripts retain their exact text.
    for name in ("subject_account", "subject_domain", "group_name", "member_name"):
        if name in details:
            details[name] = details[name].casefold()
    canonical = {
        "timestamp": timestamp.isoformat(), "event_id": event_id, "host": host,
        "account": account.casefold(), "domain": domain.casefold(),
        "source_ip": source_ip.casefold(), "details": details,
    }
    # EventRecordID, if available, keeps different records with identical content
    # and timestamps distinct. Export-only metadata does not change the ID.
    fingerprint = hashlib.sha256(json.dumps(canonical, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode("utf-8")).hexdigest()
    return Event(id=fingerprint, timestamp=timestamp, event_id=event_id, host=host,
                 account=canonical["account"], domain=canonical["domain"],
                 source_ip=canonical["source_ip"], details=details, raw=dict(record))


def normalize_records(records: Iterable[Mapping[str, Any]], assume_timezone: str | None = None) -> list[Event]:
    normalized: dict[str, Event] = {}
    count = 0
    for index, record in enumerate(records, start=1):
        count = index
        if index > MAX_RECORDS:
            raise IngestionError(f"Too many events. Split the export into files containing at most {MAX_RECORDS:,} records.")
        try:
            event = normalize_event(record, assume_timezone)
        except IngestionError as exc:
            raise IngestionError(f"Record {index}: {exc}") from exc
        normalized.setdefault(event.id, event)
    if not count:
        raise IngestionError("No events found. Upload a CSV with a header and rows, or a JSON event array.")
    return sorted(normalized.values(), key=lambda event: (event.timestamp, event.id))


def read_events(content: bytes | str, filename: str, assume_timezone: str | None = None) -> list[Event]:
    suffix = Path(filename).suffix.casefold()
    if suffix not in {".csv", ".json"}:
        raise IngestionError("Unsupported file type. Upload a .csv or .json Windows Event export; .evtx support is planned.")
    if isinstance(content, bytes):
        if len(content) > MAX_CONTENT_BYTES:
            raise IngestionError("Upload exceeds the 10 MiB limit. Split the export into smaller files.")
        try:
            text = content.decode("utf-8-sig")
        except UnicodeDecodeError as exc:
            raise IngestionError("The export is not UTF-8. Save it as UTF-8 CSV/JSON and try again.") from exc
    elif isinstance(content, str):
        text = content.lstrip("\ufeff")
        try:
            text_size = len(text.encode("utf-8"))
        except UnicodeEncodeError as exc:
            raise IngestionError("The export contains invalid Unicode. Save it as UTF-8 and try again.") from exc
        if text_size > MAX_CONTENT_BYTES:
            raise IngestionError("Upload exceeds the 10 MiB limit. Split the export into smaller files.")
    else:
        raise IngestionError("Upload content must be text or bytes.")
    if suffix == ".json":
        try:
            value = json.loads(text)
        except (json.JSONDecodeError, RecursionError) as exc:
            raise IngestionError("Invalid JSON. Upload a valid event array, a single event object, or an object containing an 'events' array.") from exc
        if isinstance(value, Mapping) and "events" in value:
            records = value["events"]
        elif isinstance(value, Mapping) and "Events" in value:
            records = value["Events"]
        elif isinstance(value, Mapping):
            records = [value]
        else:
            records = value
        if not isinstance(records, list):
            raise IngestionError("JSON events must be an array of event objects.")
    else:
        try:
            reader = csv.DictReader(io.StringIO(text), strict=True)
            if not reader.fieldnames:
                raise IngestionError("CSV is empty. Include a header with timestamp and event_id fields.")
            header_keys = [_key(name) for name in reader.fieldnames]
            if len(set(header_keys)) != len(header_keys):
                raise IngestionError("CSV contains duplicate column names. Use one column for each field.")
            records = []
            for index, row in enumerate(reader, start=1):
                if index > MAX_RECORDS:
                    raise IngestionError(f"Too many events. Split the export into at most {MAX_RECORDS:,} records per file.")
                if None in row or any(value is None for value in row.values()):
                    raise IngestionError(f"CSV row {index + 1} does not match the header. Quote fields containing commas.")
                records.append(row)
        except csv.Error as exc:
            raise IngestionError("Invalid CSV. Check quoting and ensure each row matches the header.") from exc
    return normalize_records(records, assume_timezone)


parse_events = read_events
